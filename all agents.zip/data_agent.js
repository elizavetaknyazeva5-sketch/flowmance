export function runAIData(context) {
  return {
    output: {
      dataSources: context.dataSources || [],
      insights: "Ключевые паттерны поведения пользователей",
    },
    recommendations: ["Очистить данные", "Выделить ключевые метрики"],
    nextAgents: ["business_analyst"],
  };
}