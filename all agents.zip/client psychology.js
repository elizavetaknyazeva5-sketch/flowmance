export function runPsychology(context) {
  return {
    output: {
      painPoints: [
        "Нет времени",
        "Дорого нанимать команду",
        "Нет системности",
      ],
      triggers: ["экономия", "простота", "скорость"],
    },
    recommendations: [
      "Упростить вход",
      "Показать кейсы",
    ],
    nextAgents: ["ux"],
  };
}