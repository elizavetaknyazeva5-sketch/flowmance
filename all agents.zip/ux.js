export function runUX(context) {
  return {
    output: {
      flow: [
        "Главная",
        "Выбор задачи",
        "Уточняющие вопросы",
        "Результат",
      ],
      principles: ["минимум шагов", "визуальная ясность"],
    },
    recommendations: [
      "Убрать лишние клики",
      "Сделать progress bar",
    ],
    nextAgents: ["designer"],
  };
}