export function runCallBot(context) {
  return {
    output: {
      scripts: ["Первичный контакт"],
    },
    recommendations: ["Четкое приветствие"],
    nextAgents: ["sales"],
  };
}