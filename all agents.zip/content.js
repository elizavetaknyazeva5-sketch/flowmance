export function runContent(context) {
  return {
    output: {
      contentTypes: [
        "Лендинг тексты",
        "Email",
        "Сценарии",
      ],
    },
    recommendations: [
      "Говорить языком боли",
      "Меньше маркетинга — больше пользы",
    ],
    nextAgents: ["sales"],
  };
}