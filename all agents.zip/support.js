export function runSupport(context) {
  return {
    output: {
      channels: ["Chat", "Email"],
    },
    recommendations: ["Быстрое реагирование"],
    nextAgents: [],
  };
}