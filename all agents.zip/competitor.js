export function runAICompetitor(context) {
  return {
    output: {
      advantages: ["Скорость", "Системность"],
    },
    recommendations: ["Сравнительные таблицы"],
    nextAgents: [],
  };
}