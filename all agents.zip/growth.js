export function runGrowth(context) {
  return {
    output: {
      metrics: ["CAC", "LTV", "Activation"],
      experiments: ["A/B CTA", "Новые сегменты"],
    },
    recommendations: [
      "Измерять каждую гипотезу",
    ],
    nextAgents: ["management"],
  };
}