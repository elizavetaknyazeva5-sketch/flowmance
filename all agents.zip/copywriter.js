export function runAICopywriter(context) {
  return {
    output: {
      copies: ["Hero headline", "CTA", "Email"],
    },
    recommendations: ["Писать от боли, не от функции"],
    nextAgents: ["ai_brand_manager"],
  };
}