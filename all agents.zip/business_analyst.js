export function runBusinessAnalyst(context) {
  return {
    output: {
      findings: ["Рост конверсии на этапе выбора"],
      bottlenecks: ["Onboarding"],
    },
    recommendations: ["Упростить первый шаг"],
    nextAgents: ["ai_strategy"],
  };
}