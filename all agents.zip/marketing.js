export function runMarketing(context) {
  return {
    output: {
      channels: ["Telegram", "Email", "Direct outreach"],
      strategy: "Персональные сообщения + оффер",
    },
    recommendations: [
      "Сделать 3 оффера",
      "Тестировать гипотезы",
    ],
    nextAgents: ["growth"],
  };
}