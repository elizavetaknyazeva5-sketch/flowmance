import { AgentTemplate } from "./AgentTemplate";

export const onboarding = {
  ...AgentTemplate,

  id: "onboarding",
  name: "Onboarding Agent",
  department: "core",
  role: "Ввод пользователя и бизнеса в систему",

  description:
    "Проводит пользователя через быстрый онбординг и подготавливает систему к работе.",

  inputs: [
    "Тип пользователя (B2C / B2B)",
    "Цель использования Flowmance",
    "Уровень опыта",
    "Размер команды"
  ],

  questions: [
    "Вы используете Flowmance для себя или бизнеса?",
    "Какую задачу хотите решить в первую очередь?",
    "Есть ли у вас команда?",
    "Какой результат нужен быстрее всего?",
    "Нужна ли автоматизация процессов?"
  ],

  outputs: [
    "Рекомендованные агенты",
    "Стартовый сценарий",
    "Маршрут пользователя"
  ],

  scenarios: [
    "Первый вход в систему",
    "Выбор агентов",
    "Запуск первого сценария"
  ],

  dependsOn: ["ai_training"],

  memory: {
    shared: true,
    write: false
  },

  ui: {
    icon: "🚀",
    cta: "Начать работу",
    time: "1 минута",
    category: "Core"
  }
};