export function runSales(context) {
  return {
    output: {
      scripts: [
        "Первый контакт",
        "Работа с возражениями",
      ],
    },
    recommendations: [
      "Фокус на результат",
      "Минимум давления",
    ],
    nextAgents: [],
  };
}