export function runAICRM(context) {
  return {
    output: {
      segments: ["B2C", "B2B"],
    },
    recommendations: ["Автоматизировать follow-up"],
    nextAgents: ["sales"],
  };
}