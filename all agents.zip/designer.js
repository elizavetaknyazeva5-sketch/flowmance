export function runDesigner(context) {
  return {
    output: {
      style: "минимализм + premium",
      colors: ["#4c1d95", "#ffffff", "#0f172a"],
      components: ["cards", "timeline", "cta"],
    },
    recommendations: [
      "Использовать большие отступы",
      "Акцент на CTA",
    ],
    nextAgents: ["webbuilder"],
  };
}