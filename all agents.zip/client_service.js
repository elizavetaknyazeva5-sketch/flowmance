export function runClientService(context) {
  return {
    output: {
      scenarios: ["Поддержка", "Онбординг", "Апселл"],
    },
    recommendations: ["Ответ ≤ 2 минут"],
    nextAgents: [],
  };
}