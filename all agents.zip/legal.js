export function runLegal(context) {
  return {
    output: {
      risks: ["GDPR", "Terms"],
    },
    recommendations: ["Обновлять документы"],
    nextAgents: ["ai_compliance"],
  };
}