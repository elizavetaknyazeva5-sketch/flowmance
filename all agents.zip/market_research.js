export function runMarketResearch(context) {
  return {
    output: {
      competitors: ["Notion AI", "AutoGPT"],
      gaps: ["Нет синхронных агентов"],
    },
    recommendations: ["Давить на отличие"],
    nextAgents: ["ai_competitor"],
  };
}