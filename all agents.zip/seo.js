export function runAISeo(context) {
  return {
    output: {
      keywords: ["AI агенты", "AI для бизнеса"],
    },
    recommendations: ["SEO + лендинги под use-case"],
    nextAgents: ["content"],
  };
}