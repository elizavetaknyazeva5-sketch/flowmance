// frontend/src/components/PromptInput.jsx
import { useState } from "react";
import { runAgent } from "../api/agents";

export default function PromptInput() {
  const [prompt, setPrompt] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleRun() {
    if (!prompt) return;

    setLoading(true);
    setResult("");

    try {
      const data = await runAgent("ai_ux", prompt);
      setResult(data.result || JSON.stringify(data));
    } catch (error) {
      setResult("Ошибка выполнения задачи");
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: 600, margin: "0 auto" }}>
      <h2>Опишите задачу</h2>

      <textarea
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="Например: Создай UX-структуру лендинга для IT-сервиса"
        rows={4}
        style={{ width: "100%", padding: 12 }}
      />

      <button
        onClick={handleRun}
        disabled={loading}
        style={{
          marginTop: 12,
          padding: "10px 20px",
          cursor: "pointer",
        }}
      >
        {loading ? "Выполняется..." : "Запустить AI"}
      </button>

      {result && (
        <div style={{ marginTop: 20 }}>
          <h3>Результат</h3>
          <pre
            style={{
              background: "#111",
              color: "#0f0",
              padding: 12,
              whiteSpace: "pre-wrap",
            }}
          >
            {result}
          </pre>
        </div>
      )}
    </div>
  );
}
