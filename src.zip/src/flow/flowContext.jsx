import { createContext, useContext, useState } from "react";

const FlowContext = createContext(null);

const initialFlow = {
  ui: {
    page: "home",      // home | start | pipeline | result
    loading: false,
    error: null
  },
  scenario: null,
  input: { answers: null },
  pipeline: [],
  memory: {},
  finalResult: null
};

export function FlowProvider({ children }) {
  const [flow, setFlow] = useState(initialFlow);

  return (
    <FlowContext.Provider value={{ flow, setFlow }}>
      {children}
    </FlowContext.Provider>
  );
}

export function useFlow() {
  const ctx = useContext(FlowContext);
  if (!ctx) {
    throw new Error("useFlow must be used inside FlowProvider");
  }
  return ctx;
}
