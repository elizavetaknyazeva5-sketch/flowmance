import { flowContext } from "../flow/flowContext";
import { runWebbuilder } from "../agents/webbuilder";
import { runMarketing } from "../agents/marketing";

export function runFlow() {
  if (flowContext.goal === "site") {
    return runWebbuilder(flowContext);
  }

  if (flowContext.goal === "marketing") {
    return runMarketing(flowContext);
  }

  return {
    error: "Цель не поддерживается",
  };
}