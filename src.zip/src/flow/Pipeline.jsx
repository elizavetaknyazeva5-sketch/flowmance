import { useEffect, useState } from "react";
import { getAgents, runAgent } from "../api/api";
import { runPipeline } from "../runPipeline";


export default function Pipeline() {
  const [status, setStatus] = useState("idle");
  const [agents, setAgents] = useState([]);
  const [results, setResults] = useState(null);
  const [context, setContext] = useState({});

  useEffect(() => {
    async function loadAgents() {
      const list = await getAgents();
      setAgents(list);
      // Инициализируем статусы
      const initialResults = {};
      list.forEach(a => (initialResults[a] = { status: "idle", summary: "" }));
      setResults(initialResults);
    }
    loadAgents();
  }, []);

  const handleRunAgent = async (agentName) => {
    setResults(prev => ({ 
      ...prev, 
      [agentName]: { ...prev[agentName], status: "loading" } 
    }));

    const result = await runAgent(agentName, context);

    setResults(prev => ({ 
      ...prev, 
      [agentName]: { ...prev[agentName], status: "done", summary: result.summary } 
    }));

    // Обновляем контекст для следующих агентов
    setContext(prev => ({ ...prev, [agentName]: result }));
  };

  const runAgent = async () => {
    for (const agent of agents) {
      await handleRunAgent(agent);
    }
  };

  return (
    <div style={{ padding: 40, fontFamily: "sans-serif" }}>
      <h1> Flowmance Pipeline</h1>

      <button
        onClick={runPipeline}
        disabled={running}
        style={{
          padding: "10px 20px",
          fontSize: 16,
          marginBottom: 20
        }}
      >
        {running ? "Агенты работают..." : "Запустить pipeline"}
      </button>

      {/* Progress bar */}
      <div style={{ height: 10, background: "#eee", marginBottom: 20 }}>
        <div
          style={{
            height: "100%",
          
            background: "#4caf50",
            transition: "0.3s"
          }}
        />
      </div>

      {/* Agent list */}
      <div>
        {agents.map(agent => (
          <div
            key={agent.name}
            style={{
              padding: 12,
              border: "1px solid #ddd",
              marginBottom: 10,
              borderRadius: 6
            }}
          >
            <strong>{agent.label}</strong>
            <div>Status: {agent.status}</div>

            {agent.result && (
              <pre
                style={{
                  background: "#f9f9f9",
                  padding: 10,
                  marginTop: 10,
                  whiteSpace: "pre-wrap"
                }}
              >
                {JSON.stringify(agent.result, null, 2)}
              </pre>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
