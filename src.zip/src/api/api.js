// Получение списка доступных агентов
export async function getAgents() {
  try {
    const res = await fetch("http://127.0.0.1:8001/agents");
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    return Object.keys(data); // возвращаем массив имён агентов
  } catch (err) {
    console.error("Ошибка getAgents:", err);
    return [];
  }
}

// Запуск конкретного агента
export async function runAgent(agentName, context = {}) {
  const answers = context.answers || { test: true }; // fallback
  try {
    const res = await fetch(`http://127.0.0.1:8001/agents/${agentName}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(answers)
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`HTTP ${res.status}: ${text}`);
    }

    const data = await res.json();

    return {
      agent: agentName,
      summary: data.summary || `Результат от ${agentName}`,
      input: answers,
      data: data.data || null
    };
  } catch (err) {
    console.error("Ошибка runAgent:", err);
    return {
      agent: agentName,
      summary: `Ошибка при вызове агента ${agentName}: ${err.message}`,
      input: answers,
      data: null
    };
  }
}
