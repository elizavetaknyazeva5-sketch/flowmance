import http from "./http";

export const runWorkflow = (workflowId, prompt) =>
  http.post("/workflows/run", {
    workflow_id: workflowId,
    prompt
  });
