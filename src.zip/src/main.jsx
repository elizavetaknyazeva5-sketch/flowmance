import React from "react";
import ReactDOM from "react-dom/client";
import App from "./app";
import { FlowProvider } from "./store/flowProvider";

ReactDOM.createRoot(document.getElementById("root")).render(
  <FlowProvider>
    <App />
  </FlowProvider>
);
