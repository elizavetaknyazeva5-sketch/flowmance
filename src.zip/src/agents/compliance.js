export function runCompliance(context) {
  return {
    output: {
      status: "Соответствие требованиям",
    },
    recommendations: ["Регулярные проверки"],
    nextAgents: [],
  };
}