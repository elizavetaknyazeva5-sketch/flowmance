export function runTraffic(context) {
  return {
    output: {
      channels: ["Direct", "Cold outreach"],
    },
    recommendations: ["Четкий оффер в 1 строку"],
    nextAgents: ["lead_scoring"],
  };
}