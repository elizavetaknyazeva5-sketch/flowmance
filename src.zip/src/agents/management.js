export function runManagement(context) {
  return {
    output: {
      roadmap: ["MVP", "Рост", "Автоматизация"],
      risks: ["перегруз", "отсутствие фокуса"],
    },
    recommendations: [
      "Фиксировать решения",
      "Регулярные ревью",
    ],
    nextAgents: [],
  };
}