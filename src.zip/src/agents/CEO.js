export function runCEO(context) {
  return {
    output: {
      goal: context.goal,
      strategy: "Рост через автоматизацию и скорость",
      priority: "MVP → клиенты → масштабирование",
    },
    recommendations: [
      "Запустить MVP за 7 дней",
      "Собрать обратную связь",
      "Усилить маркетинг",
    ],
    nextAgents: ["psychology", "marketing"],
  };
}