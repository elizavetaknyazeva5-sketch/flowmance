export function runVideoCreator(context) {
  return {
    output: {
      formats: ["Shorts", "Explainer", "Ads"],
    },
    recommendations: ["Фокус на 3 секундах хука"],
    nextAgents: ["smm"],
  };
}