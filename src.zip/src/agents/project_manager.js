export function runAIProjectManager(context) {
  return {
    output: {
      plan: ["Задачи", "Сроки", "Ответственные"],
    },
    recommendations: ["Декомпозиция до 1 дня"],
    nextAgents: ["ai_operations"],
  };
}