import { runAIData } from "./data_agent";
import { runVideoCreator } from "./video_creator";
import { runAIExperiments } from "./experiments";
import { runAITraining } from "./training";
import { runAICRM } from "./crm";
import { runAIProjectManager } from "./project_manager";
import { runWorkflowBuilder } from "./workflow";
import { runBrandManager } from "./brand_manager";
import { runAICompetitor } from "./competitor";
import { runAICopywriter } from "./copywriter";
import { runMarketResearch } from "./market_research";
import { runAISeo } from "./seo";
import { runSMM } from "./smm";
import { runTraffic } from "./traffic";
import { runAccountant } from "./accountant";
import { runAdminAssistant } from "./admin_assistant";
import { runCompliance } from "./compliance";
import { runHR } from "./hr";
import { runLegal } from "./legal";
import { runOnboarding } from "./onboarding";
import { runCallBot } from "./call_bot";
import { runClientService } from "./client_service";
import { runLeadScoring } from "./lead_scoring";
import { runBusinessAnalyst } from "./business_analyst";
import { runFinanceDocs } from "./finance_docs";
import { runFinancialAnalyst } from "./financial";
import { runAIOperations } from "./operations";
import { runAIProduct } from "./product";
import { runAIStrategy } from "./strategy";
import { runSupport } from "./support";
import { ai_training } from "./training";
import { onboarding } from "./onboarding";
import { admin_assistant } from "./admin_assistant"

export const agents = {
  ai_training,
  onboarding,
  admin_assistant,
  ai_data_agent: runAIData,
  video_creator: runVideoCreator,
  ai_experiments: runAIExperiments,
  ai_crm: runAICRM,
  ai_project_manager: runAIProjectManager,
  ai_workflow: runWorkflowBuilder,
  ai_brand_manager: runBrandManager,
  ai_competitor: runAICompetitor,
  ai_copywriter: runAICopywriter,
  market_research: runMarketResearch,
  ai_seo: runAISeo,
  smm: runSMM,
  traffic: runTraffic,
  accountant: runAccountant,
  ai_compliance: runCompliance,
  hr: runHR,
  legal: runLegal,
  call_bot: runCallBot,
  client_service: runClientService,
  lead_scoring: runLeadScoring,
  business_analyst: runBusinessAnalyst,
  finance_docs: runFinanceDocs,
  financial: runFinancialAnalyst,
  ai_operations: runAIOperations,
  ai_product: runAIProduct,
  ai_strategy: runAIStrategy,
  support: runSupport,
};