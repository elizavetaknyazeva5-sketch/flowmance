export function runBrandManager(context) {
  return {
    output: {
      tone: "Уверенный, умный, технологичный",
      positioning: "AI как команда, а не инструмент",
    },
    recommendations: ["Сохранять единый голос"],
    nextAgents: [],
  };
}