export function runAIProduct(context) {
  return {
    output: {
      roadmap: ["MVP", "Scale"],
    },
    recommendations: ["Слушать пользователей"],
    nextAgents: [],
  };
}