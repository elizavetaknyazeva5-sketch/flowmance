export function runFinanceDocs(context) {
  return {
    output: {
      docs: ["Счета", "Акты"],
    },
    recommendations: ["Автоматизировать генерацию"],
    nextAgents: [],
  };
}