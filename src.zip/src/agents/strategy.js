export function runAIStrategy(context) {
  return {
    output: {
      strategy: "Рост через AI-отделы",
    },
    recommendations: ["Фокус на core value"],
    nextAgents: [],
  };
}