export function runFinancialAnalyst(context) {
  return {
    output: {
      forecast: "Рост при масштабировании",
    },
    recommendations: ["Следить за LTV"],
    nextAgents: [],
  };
}