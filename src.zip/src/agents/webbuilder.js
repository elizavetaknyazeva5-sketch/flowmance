export function runWebbuilder(context) {
  return {
    structure: [
      "Hero",
      "Преимущества",
      "Сценарии использования",
      "CTA",
    ],
    copy: {
      hero: "ИИ-система для роста вашего бизнеса",
    },
    nextSteps: [
      "Уточнить стиль",
      "Добавить SEO",
      "Сгенерировать код",
    ],
  };
}