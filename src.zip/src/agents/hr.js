export function runHR(context) {
  return {
    output: {
      roles: ["AI supervisor"],
    },
    recommendations: ["Четкие роли"],
    nextAgents: [],
  };
}