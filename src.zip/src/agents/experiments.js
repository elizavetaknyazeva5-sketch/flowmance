export function runAIExperiments(context) {
  return {
    output: {
      experiments: ["A/B тест CTA", "Новый onboarding flow"],
    },
    recommendations: ["Тестировать 1 гипотезу за раз"],
    nextAgents: ["growth"],
  };
}