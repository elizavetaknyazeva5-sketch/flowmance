export function runLeadScoring(context) {
  return {
    output: {
      scoreRules: ["Интерес", "Размер", "Срочность"],
    },
    recommendations: ["Фокус на warm лидах"],
    nextAgents: ["client_service"],
  };
}