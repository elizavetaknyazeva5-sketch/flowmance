export function runAccountant(context) {
  return {
    output: {
      reports: ["Доходы", "Расходы"],
    },
    recommendations: ["Контроль cashflow"],
    nextAgents: ["financial_analyst"],
  };
}