import { AgentTemplate } from "./AgentTemplate";

export const admin_assistant = {
  ...AgentTemplate,

  id: "admin_assistant",
  name: "Admin Assistant",
  department: "operations",
  role: "Административная поддержка и рутина",

  description:
    "Берёт на себя административные и организационные задачи бизнеса.",

  inputs: [
    "Задачи",
    "Списки",
    "Документы",
    "Письма",
    "Процессы"
  ],

  questions: [
    "Какую административную задачу нужно выполнить?",
    "Есть ли шаблоны или формат?",
    "Срочность задачи?",
    "Для кого результат?",
    "Нужно ли сохранить в системе?"
  ],

  outputs: [
    "Документы",
    "Планы",
    "Письма",
    "Структурированные данные"
  ],

  scenarios: [
    "Подготовка документов",
    "Организация задач",
    "Работа с письмами и списками"
  ],

  memory: {
    shared: true,
    write: true
  },

  ui: {
    icon: "🗂",
    cta: "Делегировать задачу",
    time: "2–5 минут",
    category: "Operations"
  }
};