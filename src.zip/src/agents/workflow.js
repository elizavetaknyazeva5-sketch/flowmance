export function runWorkflowBuilder(context) {
  return {
    output: {
      workflows: ["Onboarding", "Контент"],
    },
    recommendations: ["Минимум ручных шагов"],
    nextAgents: [],
  };
}