import "./index.css";
import { useState } from "react";
import Start from "./pages/Start.jsx";
import Pipeline from "./flow/Pipeline.jsx";
import { runAgent } from "./api/api.js";
import { selectAgents } from "./selectAgents";

export default function App() {
  const [page, setPage] = useState("home");
  const [agents, setAgents] = useState([]);
  const [answers, setAnswers] = useState(null);
  const [results, setResults] = useState([]);
  const [runPipelineFlag, setRunPipelineFlag] = useState(false);
  const [showPipeline, setShowPipeline] = useState(false);

  const handlePipelineFinish = (context) => {
    console.log("Pipeline завершён:", context);
    setRunPipelineFlag(false);
  };

  const runPipeline = async (inputAnswers) => {
    setShowPipeline(true);
    setResults(agents.map(a => ({ agent: a, status: "loading", result: null })));
    let context = { answers: inputAnswers };

    for (const agent of agents) {
      const result = await runAgent(agent, context);
      context = { ...context, [agent.name]: result };
      setResults(prev =>
        prev.map(step =>
          step.agent === agent
            ? { ...step, status: "done", result }
            : step
        )
      );
    }

    handlePipelineFinish(context);
  };

  // ---------- START ----------
  if (page === "start") {
    return (
      <Start
        onBack={() => setPage("home")}
        onSubmit={(formAnswers) => {
          const selected = selectAgents(formAnswers);
          setAnswers(formAnswers);
          setAgents(selected);
          setPage("pipeline");
        }}
      />
    );
  }

  // ---------- PIPELINE ----------
  if (page === "pipeline") {
    return (
      <Pipeline
        agents={agents}
        answers={answers}
        onFinish={() => setPage("home")}
      />
    );
  }
   
  // ---------- HOME ----------
  return (
    <>
      {/* HERO SECTION */}
      <section className="hero">
        <header className="header container">
          <div className="logo">Flowmance</div>

          <input className="search" placeholder="Поиск" />

          <nav className="menu">
            <a>Агенты</a>
            <a>Отделы</a>
            <a>Безопасность</a>
            <a>Тарифы</a>
            <a>Для бизнеса</a>
            <a>База знаний</a>
          </nav>

          <button className="login-btn">Регистрация / Вход</button>
        </header>

        <div className="hero-content container">
          <p className="hero-subtitle">
            Flowmance OS — AI-инфраструктура, которая выполняет за вас 60–80% процессов компании
          </p>

          <h1 className="hero-title">
            Выберите AI-специалиста, который выполнит задачи за 5% от стоимости сотрудников
          </h1>

          <p className="hero-description">
            Или опишите задачу — мы подберем агента онлайн за 1 минуту без звонков
          </p>

          <div className="hero-action">
            <input className="task-input" placeholder="Описать задачу" />
          <button className="select-btn" onClick={() => setPage("start")}>
            Подобрать
          </button>
          </div>
        </div>
      </section>

      {/* PIPELINE SECTION */}
      {runPipeline && (
        <section className="pipeline-section container">
          <h2>Pipeline агентов</h2>
          <Pipeline
          agents={agents}         // берем выбранных через selectAgents
          answers={answers}
          onFinish={handlePipelineFinish}
        />

          {results.length === 0 && <p>Ожидание запуска...</p>}

          {results.map((step, i) => (
            <AgentStep key={i} {...step} />
          ))}

          {/* Кнопка перезапуска */}
          <button
            className="btn-primary"
            onClick={() => runPipeline(answers)}
          >
            Запустить заново
          </button>
        </section>
      )}

      {/* AGENTS SECTION */}
      <section className="agents-section">
        <div className="container">
          <div className="agents-header">
            <h2>38 агентов и 7 AI-отделов</h2>
            <p>
              При выборе отдела Вы описываете задачу и отвечаете на 3–5 вопросов.
              10 секунд — и Ваш запрос выполнен.
            </p>
          </div>

          <div className="agents-list">
            {[
              {
                title: "Сайт за 10 минут",
                text: "Дизайн-макет, HTML-код, SEO-оптимизация, выбор домена, хостинг и запуск.",
                primary: "Сгенерировать бесплатно",
              },
              {
                title: "Маркетинг под ключ",
                text: "Стратегия, медиаплан и каналы продвижения на основе данных и аналитики.",
                primary: "Сгенерировать бесплатно",
              },
              {
                title: "SMM и контент-мейкер",
                text: "Тексты, сценарии, посты, рассылки с учётом аудитории и стиля бренда.",
                primary: "Попробовать бесплатно",
              },
              {
                title: "Дизайн, видео и фото",
                text: "Презентации, инфографика, видео и визуалы под фирменный стиль.",
                primary: "Попробовать (2 попытки)",
              },
              {
                title: "Продажи и скрипты",
                text: "Скрипты продаж, работа с возражениями, анализ коммуникаций.",
                primary: "Попробовать (2 попытки)",
              },
              {
                title: "Управление",
                text: "Планирование, контроль сроков, отчётность и декомпозиция задач.",
                primary: "Попробовать (2 попытки)",
              },
            ].map((agent, index) => (
              <div className="agent-card" key={index}>
                <div className="agent-preview" />

                <h3>{agent.title}</h3>
                <p>{agent.text}</p>

                <div className="agent-actions">
                  <button className="btn-primary">{agent.primary}</button>
                  <button className="btn-outline">Посмотреть примеры</button>
                </div>
              </div>
            ))}
          </div>
        </div>
        </section>

        <section className="compare-section">
  <div className="compare-container">

    
    <div className="compare-side ai-side">
      <h2 className="compare-title">ИИ-отделы</h2>

      <ul className="compare-list">
        <li>Анализируют данные</li>
        <li>Генерируют стратегии</li>
        <li>Создают контент и дизайн</li>
        <li>Оптимизируют процессы</li>
        <li>Запоминают лучшие решения</li>
      </ul>

      <div className="compare-image">
        <img
          src="https://res.cloudinary.com/dcettbtpr/image/upload/v1767615358/image_5_e9r0hm.png"
          alt="AI Brain"
        />
      </div>
    </div>

    
    <div className="compare-side human-side">
      <h2 className="compare-title">Человек</h2>

      <ul className="compare-list">
        <li>Утверждает направления</li>
        <li>Принимает финальные решения</li>
        <li>Интерпретирует аналитику</li>
        <li>Оптимизирует процессы</li>
        <li>Контролирует риски и соответствие целям</li>
      </ul>

      <div className="compare-image">
        <img
          src="https://res.cloudinary.com/dcettbtpr/image/upload/v1767615348/image_6_flgeqv.png"
          alt="Human decision"
        />
      </div>
    </div>
  </div>
</section>

  <section className="agents-synchron">
    <div className="container">
        <h2 className="title">Синхронная работа агентов</h2>
        <p className="description">ИИ работает синхронно с каждым отделом и агентом.</p>
        <p className="example">Пример: Запуск стартапа (B2C / B2B)</p>

        <div className="timeline-wrapper">
            <div className="timeline-line"></div>
            <div className="steps">
                <div className="step">
                    <div className="dot"></div>
                    <span className="step-label">CEO Agent</span>
                </div>
                <div className="step">
                    <div className="dot"></div>
                    <span className="step-label">Client Psychology Agent</span>
                </div>
                <div className="step">
                    <div className="dot"></div>
                    <span className="step-label">UX Agent</span>
                </div>
                <div className="step">
                    <div className="dot"></div>
                    <span className="step-label">Designer Agent</span>
                </div>
                <div className="step">
                    <div className="dot"></div>
                    <span className="step-label">Webbuilder Agent</span>
                </div>
            </div>
        </div>
    </div>
</section>
   
    <section className="sync-section">
  <div className="sync-overlay">
    <h2>Одна цель. Три способа реализации</h2>
    <p>
      ChatGPT отвечает на вопросы. Команды координируют работу людей.
      <span>Flowmance синхронизирует работу ИИ-агентов.</span>
    </p>
  </div>

      <div className="comparison-grid">
        {/* ChatGPT */}
        <div className="comparison-card muted">
          <h3>ChatGPT</h3>
          <p className="card-subtitle">Один ИИ-помощник</p>
          <ul>
            <li>Презентации/фото создаются в одном стиле на все, это теряет индивидуальность</li>
            <li>Ручное управление</li>
            <li>Невсегда точный результат</li>
            <li>При новом чате ввод данных заново</li>
            <li>Ответы создаются под типичные случаи</li>
          </ul>
          <div className="price">1 564 ₽ / месяц</div>
          
        </div>

        {/* Flowmance */}
        <div className="comparison-card featured">
          <h3>Flowmance</h3>
          <p className="card-subtitle">Синхронизированная команда</p>
          <ul>
            <li>36 агентов в 7 отделах</li>
            <li>Уточняющие вопросы и визуал для лучшего результата</li>
            <li>Выполнение крупных задач, с которыми не справляются обычные ИИ</li>
            <li>Мгновенное масштабирование</li>
            <li>Не нужно вводить данные для каждого агента: память закрепляется на все агенты и отделы</li>
          </ul>
          <div className="price highlight">От 3 833 ₽ / месяц</div>
          <button className="cta-button">Получите ранний доступ</button>
        </div>
        {/* Human Team */}
        <div className="comparison-card muted">
          <h3>Команда людей</h3>
          <p className="card-subtitle">Традиционные сотрудники</p>
          <ul>
            <li>Высокая стоимость</li>
            <li>Издержки, связанные с коммуникацией</li>
            <li>Человеческие ошибки</li>
            <li>Требуется руководство каждым отделом</li>
            <li>Долгие сроки выполнения работ</li>
          </ul>
          <div className="price">150,000+ ₽ / месяц</div>
          
        </div>
      </div>
    </section>
  
  <section className="use-cases">
  <div className="use-cases-header">
    <h2>Реальные сценарии использования Flowmance</h2>
    <p>
      Flowmance решает не абстрактные задачи, а конкретные бизнес- и жизненные процессы —
      от запуска продукта до масштабирования компаний.
    </p>
  </div>

  <div className="use-cases-grid">
    <div className="use-case-card">
      <h3>Запуск продукта</h3>
      <p>
        ИИ-агенты берут на себя аналитику рынка, упаковку идеи, тексты,
        стратегию запуска и контент — от идеи до первых клиентов.
      </p>
      <span>Для стартапов и соло-фаундеров</span>
    </div>

    <div className="use-case-card">
      <h3>Автоматизация агентств</h3>
      <p>
        Flowmance заменяет рутину: брифинг клиентов, генерацию идей,
        подготовку контента, отчёты и внутренние процессы.
      </p>
      <span>Для маркетинговых и креативных агентств</span>
    </div>

    <div className="use-case-card featured">
      <h3>Системы роста</h3>
      <p>
        Агенты выстраивают воронки, гипотезы, тесты и аналитику,
        работая синхронно как команда роста.
      </p>
      <span>Для масштабирования бизнеса</span>
    </div>

    <div className="use-case-card">
      <h3>Контент-движки</h3>
      <p>
        Создание контента на недели вперёд: идеи, сценарии, тексты,
        визуальные концепции и адаптация под платформы.
      </p>
      <span>Для личных брендов и креаторов</span>
    </div>

    <div className="use-case-card">
      <h3>B2B-онбординг</h3>
      <p>
        Flowmance автоматизирует ввод клиентов: инструкции,
        сценарии использования, поддержку и сопровождение.
      </p>
      <span>Для SaaS и B2B-продуктов</span>
    </div>
  </div>
</section>
    </>

  );
}

