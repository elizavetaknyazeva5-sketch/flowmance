import { useState } from "react"
import { runAgent } from "../api/agents"
import { PromptInput } from "../components/PromptInput"

export default function Workspace() {
  const [prompt, setPrompt] = useState("")
  const [result, setResult] = useState("")

  const submit = async () => {
    const data = await runAgent("marketing", prompt)
    setResult(data.output)
  }

  return (
    <>
      <PromptInput value={prompt} onChange={setPrompt} />
      <button onClick={submit}>Запустить агента</button>
      <pre>{result}</pre>
    </>
  )
}
