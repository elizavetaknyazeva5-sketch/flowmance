import { runFlow } from "../flow/flowController.js";

export default function Result() {
  const result = runFlow();

  return (
    <div className="result">
      <h1>Результат</h1>

      <h3>Структура</h3>
      <ul>
        {result.structure.map((item, i) => (
          <li key={i}>{item}</li>
        ))}
      </ul>

      <h3>Следующие шаги</h3>
      {result.nextSteps.map((step, i) => (
        <button key={i}>{step}</button>
      ))}
    </div>
  );
}