import { useState } from "react";

import { runPipeline } from "../runPipeline.js"

export default function Start({ onBack = () => {}, onSubmit = () => {} }) {
  const steps = [
    {
      id: "goal",
      question: "Для чего вы хотите использовать Flowmance?",
      options: [
        "Запуск продукта",
        "Автоматизация бизнеса",
        "Контент и SMM",
        "Продажи и воронки",
        "Управление командой",
      ],
    },
    {
      id: "role",
      question: "Кто вы?",
      options: [
        "Соло-фаундер",
        "Предприниматель",
        "Маркетолог / агентство",
        "Менеджер / руководитель",
        "Другое",
      ],
    },
    {
      id: "result",
      question: "Какой результат вы хотите получить?",
      input: "Опишите желаемый результат кратко",
    },
  ];

  const [step, setStep] = useState([
  { name: "CEO", status: "idle" },
  { name: "UX", status: "idle" },
  { name: "SMM", status: "idle" },
]);
  const [answers, setAnswers] = useState({});

  const current = steps[step];

  return (
    <div className="start-page">
      <div className="start-card">

        <div className="progress">
          {steps.map((_, i) => (
            <span key={i} className={i <= step ? "active" : ""} />
          ))}
        </div>

        {step < steps.length && (
          <>
            <h1>Настройка Flowmance</h1>
            <p>Ответьте на несколько вопросов</p>

            <div className="question">{current.question}</div>

            {current.options && (
              <div className="options">
                {current.options.map(option => (
                  <div
                    key={option}
                    className={`option ${
                      answers[current.id] === option ? "selected" : ""
                    }`}
                    onClick={() =>
                      setAnswers({ ...answers, [current.id]: option })
                    }
                  >
                    {option}
                  </div>
                ))}
              </div>
            )}

            {current.input && (
              <input
                value={answers[current.id] || ""}
                onChange={(e) =>
                  setAnswers({ ...answers, [current.id]: e.target.value })
                }
                placeholder={current.input}
              />
            )}

            <div className="start-actions">
              <button onClick={onBack}>Назад</button>
              <button onClick={() => setStep(step + 1)}>
                Продолжить
              </button>
            </div>
          </>
        )}

        {step === steps.length && (
          <>
            <h2>Готово</h2>

<button className="start-btn"
  onClick={() => {
    console.log("🔥 ЗАПУСК PIPELINE");
    runPipeline(answersFromForm);
  }}
>
  Запустить
</button>

          </>
        )}
      </div>
    </div>
  );
}
