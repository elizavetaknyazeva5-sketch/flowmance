export async function runAgent(agent, context) {
  await new Promise(r => setTimeout(r, 1500));

  return {
    agent,
    summary: `Результат от ${agent}`,
    input: context.answers,
  };
}
