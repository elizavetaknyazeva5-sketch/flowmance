import { useState } from "react";

export default function Questions() {
  const [answers, setAnswers] = useState({
    question1: "",
    question2: ""
  });

  const handleChange = (e) => {
    setAnswers({ ...answers, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Ответы:", answers);
    alert("Ответы сохранены!");
  };

  return (
    <div style={{ padding: "50px" }}>
      <h2>Уточняющие вопросы</h2>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: "20px" }}>
          <label>Вопрос 1:</label><br/>
          <input 
            type="text" 
            name="question1" 
            value={answers.question1} 
            onChange={handleChange} 
            style={{ width: "300px", padding: "5px" }}
          />
        </div>

        <div style={{ marginBottom: "20px" }}>
          <label>Вопрос 2:</label><br/>
          <input 
            type="text" 
            name="question2" 
            value={answers.question2} 
            onChange={handleChange} 
            style={{ width: "300px", padding: "5px" }}
          />
        </div>

        <button type="submit" style={{ padding: "10px 20px", cursor: "pointer" }}>
          Отправить
        </button>
      </form>
    </div>
  );
}
