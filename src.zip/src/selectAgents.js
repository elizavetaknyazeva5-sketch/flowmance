import { AGENTS } from "./agentsConfig";

export function selectAgents(answers) {
  const [goal] = Object.values(answers);

  if (goal === "Запуск продукта") {
    return [...AGENTS.management, ...AGENTS.site];
  }

  if (goal === "Контент и SMM") {
    return [...AGENTS.marketing, ...AGENTS.site];
  }

  // fallback для общего агента
  return [{ name: "general_ai", url: "http://127.0.0.1:8001/general_ai" }];
}
