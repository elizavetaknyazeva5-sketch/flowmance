export const AGENTS = {
  site: [
    { name: "UX Agent", url: "http://127.0.0.1:8001/ux_agent" },
    { name: "Designer Agent", url: "http://127.0.0.1:8001/designer_agent" },
    { name: "Webbuilder Agent", url: "http://127.0.0.1:8001/webbuilder_agent" },
    { name: "SEO Agent", url: "http://127.0.0.1:8001/seo_agent" }
  ],
  marketing: [
    { name: "Growth Agent", url: "http://127.0.0.1:8001/growth_agent" },
    { name: "SMM Agent", url: "http://127.0.0.1:8001/smm_agent" },
    { name: "Copy Agent", url: "http://127.0.0.1:8001/copy_agent" }
  ],
  sales: [
    { name: "Sales Agent", url: "http://127.0.0.1:8001/sales_agent" },
    { name: "Script Agent", url: "http://127.0.0.1:8001/script_agent" }
  ],
  management: [
    { name: "CEO Agent", url: "http://127.0.0.1:8001/ai_ceo_assistant" },
    { name: "Ops Agent", url: "http://127.0.0.1:8001/ops_agent" }
  ]
};
