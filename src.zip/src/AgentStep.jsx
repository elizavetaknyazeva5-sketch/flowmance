export default function AgentStep({ agent, status, result, error }) {
  return (
    <div className={`agent-step ${status}`}>
      <div className="agent-header">
        <strong>{agent}</strong>

        {status === "loading" && <span className="spinner">⏳</span>}
        {status === "done" && <span>✅</span>}
        {status === "error" && <span>❌</span>}
      </div>

      {status === "done" && result && (
        <pre className="agent-result">
          {JSON.stringify(result, null, 2)}
        </pre>
      )}

      {status === "error" && (
        <div className="agent-error">{error}</div>
      )}
    </div>
  );
}
