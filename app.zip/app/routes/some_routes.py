# app/routes/some_routes.py
from fastapi import APIRouter

router = APIRouter()

@router.get("/ping")
async def ping():
    return {"ping": "pong"}
