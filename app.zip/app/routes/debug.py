from fastapi import APIRouter

router = APIRouter()

@router.get("/health")
async def health():
    return {"status": "ok"}

@router.get("/debug/loaded-agents")
async def loaded_agents():
    return {"loaded_agents": list()}
