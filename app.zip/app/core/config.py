from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    database_url: str | None = None
    async_database_url: str | None = None
    secret_key: str | None = None
    jwt_secret: str | None = None
    openrouter_api_key: str | None = None
    APP_NAME: str = "Flowmance"
    DEBUG: bool = True
    ALLOWED_ORIGINS: list[str] = ["*"]
    model_config = {
        "env_file": ".env",
        "extra": "ignore",   # <-- важно
    }

settings = Settings()

