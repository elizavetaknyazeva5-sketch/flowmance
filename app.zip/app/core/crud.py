from sqlalchemy.orm import Session
from app.models.user import User
from app.models.project import Project
from app.models.agent import Agent
from app.schemas import user_schema, project_schema, agent_schema
from app.core.security import get_password_hash


# --- USER CRUD ---

def create_user(db: Session, user_data: user_schema.UserCreate):
    db_user = User(
        email=user_data.email,
        name=user_data.name,
        hashed_password=get_password_hash(user_data.password)
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


def get_user_by_email(db: Session, email: str):
    return db.query(User).filter(User.email == email).first()


def get_user(db: Session, user_id: int):
    return db.query(User).filter(User.id == user_id).first()


def delete_user(db: Session, user_id: int):
    db_user = get_user(db, user_id)
    if db_user:
        db.delete(db_user)
        db.commit()
    return db_user


# --- PROJECT CRUD ---

def create_project(db: Session, project_data: project_schema.ProjectCreate, user_id: int):
    db_project = Project(
        name=project_data.name,
        description=project_data.description,
        user_id=user_id
    )
    db.add(db_project)
    db.commit()
    db.refresh(db_project)
    return db_project


def get_project(db: Session, project_id: int):
    return db.query(Project).filter(Project.id == project_id).first()


def get_projects_by_user(db: Session, user_id: int):
    return db.query(Project).filter(Project.user_id == user_id).all()


def update_project(db: Session, project_id: int, project_data: project_schema.ProjectUpdate):
    db_project = get_project(db, project_id)
    if not db_project:
        return None
    for field, value in project_data.dict(exclude_unset=True).items():
        setattr(db_project, field, value)
    db.commit()
    db.refresh(db_project)
    return db_project


# --- AGENT CRUD ---

def create_agent(db: Session, agent_data: agent_schema.AgentCreate):
    db_agent = Agent(
        name=agent_data.name,
        role=agent_data.role,
        category=agent_data.category,
        description=agent_data.description
    )
    db.add(db_agent)
    db.commit()
    db.refresh(db_agent)
    return db_agent


def get_agent(db: Session, agent_id: int):
    return db.query(Agent).filter(Agent.id == agent_id).first()


def get_agents(db: Session):
    return db.query(Agent).all()


def delete_agent(db: Session, agent_id: int):
    db_agent = get_agent(db, agent_id)
    if db_agent:
        db.delete(db_agent)
        db.commit()
    return db_agent