# Временная заглушка, так как get_user_by_id был удален из user_manager
from sqlalchemy.orm import Session
from app.models.user import User

def get_user_by_id(db: Session, user_id: int):
    return db.query(User).filter(User.id == user_id).first()

# Пример "backend" авторизации
class AuthBackend:
    def __init__(self, db):
        self.db = db

    def get_user(self, user_id: int):
        return get_user_by_id(self.db, user_id)

# Создаём экземпляр бекенда
auth_backend = AuthBackend

