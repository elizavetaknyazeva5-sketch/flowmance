# app/services/workflow_manager.py
import json
import time
from typing import Dict, Any, List
from sqlalchemy.orm import Session
from app.db import models
from app.ai_agents import agents as agent_module

def _load_params(params_text: str):
    if not params_text:
        return {}
    try:
        return json.loads(params_text)
    except:
        return {}

def run_workflow(db: Session, workflow_id: int) -> Dict[str, Any]:
    wf = db.query(models.Workflow).filter(models.Workflow.id == workflow_id).first()
    if not wf:
        return {"error": "workflow not found"}
    steps = db.query(models.WorkflowStep).filter(models.WorkflowStep.workflow_id == workflow_id).order_by(models.WorkflowStep.order).all()

    overall = []
    for step in steps:
        agent_name = step.agent_name
        params = _load_params(step.params)
        AgentClass = getattr(agent_module, agent_name, None)
        if not AgentClass:
            # save message
            msg = models.Message(workflow_id=workflow_id, step_id=step.id, role="system", content=f"Agent {agent_name} not found")
            db.add(msg); db.commit()
            overall.append({"step": step.order, "agent": agent_name, "error": "not found"})
            continue

        agent = AgentClass()
        try:
            # try async if available — we run sync here, so call run()
            out = agent.run(**params) if isinstance(params, dict) else agent.run()
        except Exception as e:
            out = {"result": "error", "payload": {"error": str(e)}}

        # persist message + result
        msg = models.Message(workflow_id=workflow_id, step_id=step.id, role="agent", content=str(out))
        db.add(msg); db.commit()
        res = models.Result(workflow_id=workflow_id, step_id=step.id, payload=json.dumps(out))
        db.add(res); db.commit()

        overall.append({"step": step.order, "agent": agent_name, "output": out})
        time.sleep(0.05)  # small throttle
    return {"workflow_id": workflow_id, "results": overall}
