import importlib
import pkgutil
from app.agents.base_agent import BaseAgent
from app import agents


def load_all_agents() -> dict[str, type[BaseAgent]]:
    """
    Автоматически загружает всех агентов из пакета app.agents
    и возвращает словарь: {"название": КлассАгента}
    """
    agent_classes = {}

    package = agents

    for _, module_name, _ in pkgutil.iter_modules(package.__path__):
        module = importlib.import_module(f"app.agents.{module_name}")

        for attr_name in dir(module):
            attr = getattr(module, attr_name)

            if isinstance(attr, type) and issubclass(attr, BaseAgent) and attr is not BaseAgent:
                agent_classes[attr.__name__] = attr

    return agent_classes
