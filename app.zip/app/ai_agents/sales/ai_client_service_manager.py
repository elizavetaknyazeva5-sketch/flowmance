from app.ai_agents.base_agent import BaseAgent

class ClientServiceManagerAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="ClientServiceManagerAgent",
            description="Поддержка клиентов, ответы на вопросы, инструкции"
        )

    async def run(self, payload: dict) -> dict:
        question = payload.get("question", "Как получить доступ к сервису?")

        prompt = f"""
Ты — эксперт клиентского сервиса.

Ответь на вопрос клиента: "{question}"

Верни JSON:
{{
  "answer": "...",
  "steps": "...",
  "related_questions": "...",
  "recommendations": "..."
}}
"""

        result = await self.ask(prompt)
        return {"client_support": result}
