from app.ai_agents.base_agent import BaseAgent

class CallBotAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="CallBotAgent",
            description="Генерация скриптов звонков"
        )

    async def run(self, payload: dict) -> dict:
        goal = payload.get("goal", "продажа услуги")
        client = payload.get("client", "B2B компания")

        prompt = f"""
Ты — эксперт по продажам и колл-центрам.

Создай скрипт звонка.

Цель: {goal}
Клиент: {client}

Ответ JSON:
{{
  "opening": "...",
  "discovery_questions": "...",
  "presentation_script": "...",
  "objections": "...",
  "closing": "...",
  "full_dialog_sample": "..."
}}
"""

        result = await self.ask(prompt)
        return {"call_script": result}
