from app.ai_agents.base_agent import BaseAgent

class AILeadScoringAgent(BaseAgent):
    def __init__(self):
        super().__init__("AIScoringAgent", "Оценка качества лидов и приоритизация")
    

    async def run(self, input_data: dict) -> str:
        leads = input_data.get("leads", [])
        prompt = f"""
Оцени эти лиды по приоритету (high/medium/low) и дай причину:
{leads}

Предложи правила для автоматической фильтрации.
"""
        return await self.ask(prompt)
