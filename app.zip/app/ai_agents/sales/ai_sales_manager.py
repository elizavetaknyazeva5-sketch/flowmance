from app.ai_agents.base_agent import BaseAgent

class AISalesAgent(BaseAgent):
    def __init__(self):
        super().__init__("AISalesAgent", "Сценарии продаж, скрипты и обработка возражений")
    

    async def run(self, input_data: dict) -> str:
        product = input_data.get("product", "Услуга")
        objections = input_data.get("objections", ["дорого"])
        prompt = f"""
Сгенерируй скрипт продаж для {product}.

Учитывай возражения: {objections}
Дай:
- сценарий холодного звонка
- сценарий переговоров
- 5 ответов на типичные возражения
"""
        return await self.ask(prompt)
