from app.ai_agents.base_agent import BaseAgent

class AIVideoCreator(BaseAgent):
    def __init__(self):
        super().__init__("AIVideoCreator", "Сценарии и раскадровки видео")

    async def run(self, payload):
        goal = payload.get("goal", "привлечение внимания")
        length = payload.get("length", "60s")
        return f"Сценарий видео на {length} для цели: {goal}"
