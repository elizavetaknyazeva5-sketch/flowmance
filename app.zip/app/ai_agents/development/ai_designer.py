from app.ai_agents.base_agent import BaseAgent

class DesignAgent(BaseAgent):
    def __init__(self):
        super().__init__("DesignAgent", "Дизайн-концепции")

    async def run(self, payload):
        theme = payload.get("theme", "")
        return f"Дизайн-концепция для темы: {theme}"
