from app.ai_agents.base_agent import BaseAgent
from app.ai_agents.llm_config import DEFAULT_LLM_CONFIG
class AIDataAgent(BaseAgent):
    def __init__(self):
        super().__init__("ai_data_agent", "Анализ данных")
        
    async def run(self, input: str):
        return {"result": f"DataAgent processed: {input}"}
    
    async def run(self, payload: dict):
        dataset = payload.get("dataset", "")
        return f"Анализ данных набора: {dataset}"

