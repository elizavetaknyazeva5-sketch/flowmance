from app.ai_agents.base_agent import BaseAgent
from pydantic import BaseModel


class WebBuilderRequest(BaseModel):
    project_name: str
    niche: str
    pages: list[str] = ["Home", "About", "Services", "Contacts"]
    style: str = "minimalistic, modern"


class AIWebBuilder(BaseAgent):
    def __init__(self):
        super().__init__(
            name="AIWebBuilder",
            description="Генерация структуры сайтов, текстов и HTML"
        )

    async def run(self, project_name: str = "Test Project", **kwargs):
        prompt = f"Сгенерируй структуру и логику сайта для проекта: {project_name}"
        return await self.ask(prompt)

        prompt = f"""
Ты — AI WebBuilder.

Создай:
1. Структуру сайта
2. Тексты для страниц
3. Простейшие HTML шаблоны
4. Дизайн-рекомендации

Проект: {data.project_name}
Ниша: {data.niche}
Стиль: {data.style}
Страницы: {data.pages}

Выведи JSON со структурой:
{{
  "structure": {{...}},
  "texts": {{...}},
  "html": {{...}},
  "design": "..."
}}
"""

        result = await self.ask(prompt)
        return result
