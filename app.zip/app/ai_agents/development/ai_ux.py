from app.ai_agents.base_agent import BaseAgent
from app.schemas.schemas import AgentRequest, AgentResponse


def run(req: AgentRequest) -> AgentResponse:
    return AgentResponse(
        agent="ux",
        summary="Предложена структура интерфейса",
        data={
            "screens": [
                "Home",
                "Pipeline progress",
                "Agent results"
            ],
            "logic": "Пошаговое выполнение агентов",
            "based_on": req.context
        }
    )

class UXAgent(BaseAgent):
    def __init__(self):
        super().__init__("UXAgent", "UX анализ")

    async def run(self, payload):
        page = payload.get("page", "")
        return f"UX-анализ страницы: {page}"
