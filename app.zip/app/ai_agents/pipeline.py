import asyncio
from app.ai_agents.agents import AGENTS

async def run_pipeline():
    context = {}

# 1. Последовательный агент
    ceo = AGENTS["ceo"]
    context["ceo"] = await ceo.run(context)

    # 2. Параллельные агенты
    parallel_agents = ["ux", "marketing"]

    results = await asyncio.gather(
        *[AGENTS[name].run(context) for name in parallel_agents]
    )

    for result in results:
        context[result["agent"]] = result

    return {
        "agent": "pipeline",
        "summary": "Pipeline выполнен",
        "data": context
    }