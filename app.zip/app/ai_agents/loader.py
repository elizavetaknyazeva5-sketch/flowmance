import importlib
import pkgutil
import inspect
from pathlib import Path

# глобальное хранилище агентов
loaded_agents = {}


def load_all_agents():
    """
    Возвращает уже загруженных агентов.
    Не перезаписывает loaded_agents!
    """
    return loaded_agents


def load_agents():
    """
    Автозагрузка всех агентов из папки app/ai_agents/
    """

    base_path = Path(__file__).parent  # app/ai_agents/
    package_name = "app.ai_agents"

    for module_info in pkgutil.walk_packages([str(base_path)], prefix=f"{package_name}."):
        module_name = module_info.name

        try:
            module = importlib.import_module(module_name)
        except Exception as e:
            print(f"❌ Ошибка импорта модуля {module_name}: {e}")
            continue

        # Ищем классы агентов
        for name, obj in inspect.getmembers(module, inspect.isclass):

            # фильтруем только классы, которые находятся в этом модуле
            if obj.__module__ != module_name:
                continue

            # пропускаем BaseAgent
            if name.lower() == "baseagent":
                continue

            try:
                # пробуем создать объект класса
                instance = obj()
            except TypeError:
                # если конструктор требует аргументы — пропускаем
                continue
            except Exception as e:
                print(f"⚠ Ошибка инициализации агента {name}: {e}")
                continue

            # имя агента
            agent_name = getattr(obj, "name", name)

            loaded_agents[agent_name] = instance

    print(f"✔ Загруженные агенты: {list(loaded_agents.keys())}")
