# app/ai_agents/routes.py
from fastapi import APIRouter, HTTPException
from app.ai_agents.registry import agent_registry
from app.schemas.schemas import AgentRequest
from pydantic import BaseModel
from typing import Any, Dict, Optional
from app.ai_agents.pipeline import run_pipeline
import asyncio
router = APIRouter(prefix="/agents")

# Общий контекст для pipeline
context: Dict[str, dict] = {}

@router.get("/general_ai")
async def general_ai():
    return {"status": "ok"}

@router.post("/run_agent/{agent_name}")
async def run_agent(agent_name: str, input_data: Dict = {}):
    agent = agent_registry.get(agent_name)
    if agent_name not in agent_registry:
        raise HTTPException (status_code=404, detail="Agent not found")
    
    agent = agent_registry[agent_name]
    result = await agent.run(input_data, context)
    
    return {
        "status": "ok",
        "agent": agent_name,
        "data": result
    }

    # Сохраняем результат в контексте
    context[agent.name] = result
    return result

@router.post("/run_pipeline")
async def run_pipeline(input_data: Dict = {}):
    """Запускает всех агентов последовательно, передавая общий контекст"""
    results = []
    for name, agent in agent_registry.items():
        res = await agent.run(input_data, context)
        context[agent.name] = res
        results.append(res)
    return results

@router.post("/run_parallel")
async def run_parallel(input_data: Dict = {}):
    """Запуск всех агентов параллельно"""
    tasks = [agent.run(input_data, context) for agent in agent_registry.values()]
    results = await asyncio.gather(*tasks)
    for r in results:
        context[r["agent"]] = r
    return results