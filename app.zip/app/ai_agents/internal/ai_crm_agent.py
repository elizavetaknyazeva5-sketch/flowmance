from app.ai_agents.base_agent import BaseAgent

class CRMAgent(BaseAgent):
    def __init__(self):
        super().__init__("CRMAgent", "Процессы CRM и воронки продаж")

    async def run(self, input_data: dict) -> str:
        pipeline = input_data.get("pipeline", "стандартная воронка")
        prompt = f"""
Составь CRM-процессы и воронку на основе: {pipeline}
Включи автоматизации, триггеры и метрики на каждом шаге.
"""
        return await self.ask(prompt)
