from app.ai_agents.base_agent import BaseAgent

class AIProjectManager(BaseAgent):
    def __init__(self):
        super().__init__("AIProjectManager", "Управление проектами и дедлайнами")

    async def run(self, payload: dict):
        prompt = f"Проанализируй проект: {payload}"
        return await self.ask(prompt)