from app.ai_agents.base_agent import BaseAgent

class WorkflowBuilderAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="WorkflowBuilderAgent",
            description="Создание бизнес-воркфлоу, процессов, пайплайнов"
        )

    async def run(self, payload: dict) -> dict:
        goal = payload.get("goal", "оптимизация процессов")
        department = payload.get("department", "operations")

        prompt = f"""
Ты — эксперт по бизнес-процессам и workflow.

Создай полный workflow для цели: "{goal}"
Отдел: {department}

Формат JSON:
{{
  "stages": "...",
  "tools": "...",
  "responsibles": "...",
  "timelines": "...",
  "risks": "...",
  "automations": "...",
  "final_process_description": "..."
}}
"""

        result = await self.ask(prompt)
        return {"workflow": result}
