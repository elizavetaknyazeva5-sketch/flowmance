from app.ai_agents.base_agent import BaseAgent

class ComplianceAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="ComplianceAgent",
            description="Комплаенс, нормы, политика безопасности, риски"
        )

    async def run(self, payload: dict) -> dict:
        process = payload.get("process", "обработка данных")

        prompt = f"""
Ты — комплаенс-эксперт.

Проанализируй процесс: "{process}"

Формат JSON:
{{
  "risks": "...",
  "legal_requirements": "...",
  "recommendations": "...",
  "violations_to_check": "...",
  "final_report": "..."
}}
"""

        result = await self.ask(prompt)
        return {"compliance_report": result}
