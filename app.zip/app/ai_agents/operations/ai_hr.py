from app.ai_agents.base_agent import BaseAgent

class AIHRAgent(BaseAgent):
    def __init__(self):
        super().__init__("AIHRAgent", "Анализ резюме и подбор кандидатов")

    async def run(self, input_data: dict) -> str:
        resume = input_data.get("resume", "текст резюме")
        role = input_data.get("role", "должность")
        prompt = f"""
Проанализируй резюме для роли {role}. Оцени соответствие по 5-балльной шкале и дай рекомендации.
Резюме: {resume}
"""
        return await self.ask(prompt)
