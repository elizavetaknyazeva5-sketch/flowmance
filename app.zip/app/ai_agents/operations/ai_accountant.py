from app.ai_agents.base_agent import BaseAgent

class AIAccountantAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="AIAccountantAgent",
            description="Финансовые документы, счета, акты, консультации"
        )

    async def run(self, payload: dict) -> dict:
        doc_type = payload.get("type", "invoice")
        company = payload.get("company", "ООО Пример")
        amount = payload.get("amount", 10000)

        prompt = f"""
Ты — бухгалтер и финансовый консультант.

Создай документ типа "{doc_type}" для компании "{company}" на сумму {amount}.

Формат JSON:
{{
  "document": "...",
  "legal_requirements": "...",
  "risks": "...",
  "recommendations": "..."
}}
"""

        result = await self.ask(prompt)
        return {"finance_document": result}
