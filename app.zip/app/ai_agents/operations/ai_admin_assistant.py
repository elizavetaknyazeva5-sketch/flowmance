from app.ai_agents.base_agent import BaseAgent

class AdminAssistantAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="AdminAssistantAgent",
            description="Административная поддержка, организация задач"
        )

    async def run(self, payload: dict) -> dict:
        tasks = payload.get("tasks", [])

        prompt = f"""
Ты — ассистент руководителя.

Организуй список задач: {tasks}

Верни JSON:
{{
  "prioritized_tasks": "...",
  "deadlines": "...",
  "delegation": "...",
  "calendar_events": "...",
  "notes": "..."
}}
"""

        result = await self.ask(prompt)
        return {"admin_support": result}
