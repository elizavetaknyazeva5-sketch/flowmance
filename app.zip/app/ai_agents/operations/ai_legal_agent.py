from app.ai_agents.base_agent import BaseAgent

class AILegalAgent(BaseAgent):
    def __init__(self):
        super().__init__("AILegalAgent", "Юридические шаблоны и проверка рисков")

    async def run(self, input_data: dict) -> str:
        doc_type = input_data.get("doc_type", "договор")
        context = input_data.get("context", "")
        prompt = f"""
Составь черновик {doc_type} и укажи риски по контексту: {context}
Добавь поля обязательной информации и пункты по минимизации рисков.
"""
        return await self.ask(prompt)
