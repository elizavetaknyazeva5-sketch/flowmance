from app.ai_agents.base_agent import BaseAgent

class AIOnboardingAgent(BaseAgent):
    def __init__(self):
        super().__init__("AIOnboardingAgent", "План онбординга новых сотрудников")

    async def run(self, input_data: dict) -> str:
        role = input_data.get("role", "Новая роль")
        duration = input_data.get("duration", "1 месяц")
        prompt = f"""
Составь план Onboarding для роли {role} на {duration}.
Включи: цели, задачи на неделю, метрики успеха, первые задачи.
"""
        return await self.ask(prompt)
