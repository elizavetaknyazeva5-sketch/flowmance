# app/ai_agents/base_agent.py
import os
import httpx
from typing import Any, Dict, Optional
from abc import ABC, abstractmethod


OPENAI_KEY = os.getenv("OPENAI_API_KEY")
OPENROUTER_KEY = os.getenv("OPENROUTER_API_KEY")
API_KEY = OPENAI_KEY or OPENROUTER_KEY

OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
DEFAULT_MODEL = os.getenv("OPENROUTER_MODEL", "gpt-4o-mini")

class BaseAgent(ABC):
    name = "BaseAgent"
    
    @abstractmethod
    def run(self, input: dict, context: dict) -> dict:
        pass
    async def run(self, input: str):
        return {"result": f"Base response: {input}"}
    def __init__(self, name: str = None, description: str = None):
        self.name = name
        self.description = description

    def run(self, prompt: str):
        raise NotImplementedError("Agent must implement run()")


    def call_api(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Sync stub used for tests. Returns unified response.
        For real calls use call_api_async or replace body.
        """
        if not self.api_key:
            return {"result": "запрос выполнен", "payload": {"error": "NO_API_KEY"}}
        return {"result": "запрос выполнен", "payload": payload}

    async def call_api_async(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if not self.api_key:
            return {"result": "error", "payload": {"error": "NO_API_KEY"}}
        data = {"model": DEFAULT_MODEL, "messages": [{"role":"user","content": str(payload)}]}
        headers = {"Authorization": f"Bearer {self.api_key}"}
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(OPENROUTER_URL, json=data, headers=headers)
            resp.raise_for_status()
            js = resp.json()
            content = js.get("choices", [{}])[0].get("message", {}).get("content")
            return {"result": "ok", "payload": {"text": content, "raw": js}}

    # uniform sync entrypoint
    def run(self, *args, **kwargs) -> Dict[str, Any]:
        payload = self.execute(*args, **kwargs)
        if isinstance(payload, dict):
            return self.call_api(payload)
        return self.call_api({"value": payload})

    # uniform async entrypoint
    async def run_async(self, *args, **kwargs) -> Dict[str, Any]:
        payload = self.execute(*args, **kwargs)
        if isinstance(payload, dict):
            return await self.call_api_async(payload)
        return await self.call_api_async({"value": payload})

    def execute(self, *args, **kwargs) -> Dict[str, Any]:
        raise NotImplementedError("Implement execute() in child agent")
