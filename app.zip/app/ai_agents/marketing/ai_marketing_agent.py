from app.ai_agents.base_agent import BaseAgent

class MarketingAgent(BaseAgent):
    def __init__(self):
        super().__init__("MarketingAgent", "Маркетинговая стратегия и план")



    async def run(self, input_data: dict) -> str:
        product = input_data.get("product", "Продукт")
        audience = input_data.get("audience", "ЦА")
        budget = input_data.get("budget", "бюджет не указан")
        prompt = f"""
Разработай маркетинговую стратегию для {product}.

ЦА: {audience}
Бюджет: {budget}

Включи:
- позиционирование
- каналы продвижения + примерный медиаплан
- контент-подход
- первые 3 гипотезы для тестирования
"""
        return await self.ask(prompt)
