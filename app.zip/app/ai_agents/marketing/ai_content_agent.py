from app.ai_agents.base_agent import BaseAgent

class ContentAgent(BaseAgent):
    def __init__(self):
        super().__init__("ContentAgent", "Контент план")


    async def run(self, input_data: dict) -> str:
        brief = input_data.get("brief", "Описание продукта")
        tone = input_data.get("tone", "деловой")
        prompt = f"""
Создай контент по брифу: {brief}
Тон: {tone}

Дай:
- 3 заголовка для лендинга
- 3 поста для LinkedIn (по 3–4 абзаца)
- сценарий короткого видео (до 60 сек)
"""
        return await self.ask(prompt)
