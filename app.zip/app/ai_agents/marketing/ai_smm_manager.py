from app.ai_agents.base_agent import BaseAgent
from  app.schemas.schemas  import AgentRequest, AgentResponse


def run(req: AgentRequest) -> AgentResponse:
    return AgentResponse(
        agent="smm",
        summary="Сформированы маркетинговые гипотезы",
        data={
            "channels": ["Twitter", "Product Hunt", "Landing"],
            "tone": "AI-native",
            "based_on": req.context
        }
    )

class AISMMAgent(BaseAgent):
    def __init__(self):
        super().__init__("AISMMAgent", "Контент-план и стратегии для соцсетей")

    async def run(self, input_data: dict) -> str:
        platform = input_data.get("platform", "LinkedIn")
        timeframe = input_data.get("timeframe", "1 месяц")
        prompt = f"""
Составь контент-план для {platform} на {timeframe}.

Включи:
- типы постов и частоту
- CTA и KPI
- 4 идей для постов с текстом и хештегами
"""
        return await self.ask(prompt)
