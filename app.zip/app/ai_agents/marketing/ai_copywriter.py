from app.ai_agents.base_agent import BaseAgent

class AICopywriter(BaseAgent):
    name = "AICopywriter"
    description = "Генерация копирайтинга"

    async def run(self, payload: dict):
        topic = payload.get("topic", "тема не указана")

        prompt = f"""
Напиши продающий текст по теме: {topic}.
Формат:
- заголовок
- подзаголовок
- CTA
"""
        return await self.ask(prompt)
