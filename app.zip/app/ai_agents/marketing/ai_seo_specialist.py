from app.ai_agents.base_agent import BaseAgent

class SEOAgent(BaseAgent):
    def __init__(self):
        super().__init__("SEOAgent", "SEO-анализ и рекомендации")

    async def run(self, input_data: dict) -> str:
        site = input_data.get("site", "site.example")
        keywords = input_data.get("keywords", [])
        prompt = f"""
Выполни SEO-аудит для сайта {site} по ключевым словам: {keywords}

Дай:
- главные технические проблемы
- рекомендации по контенту
- 10 приоритетных ключевых слов и план статей
"""
        return await self.ask(prompt)
