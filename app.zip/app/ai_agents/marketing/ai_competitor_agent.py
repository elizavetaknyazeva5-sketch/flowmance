from app.ai_agents.base_agent import BaseAgent

class CompetitorAgent(BaseAgent):
    def __init__(self):
        super().__init__("CompetitorAgent", "Анализ конкурентов и их стратегий")
    async def run(self, input_data: dict) -> str:
        competitors = input_data.get("competitors", [])
        prompt = f"""
Проанализируй конкурентов: {competitors}
Для каждого — сильные/слабые стороны, продуктовые отличия, каналы продаж.
"""
        return await self.ask(prompt)
