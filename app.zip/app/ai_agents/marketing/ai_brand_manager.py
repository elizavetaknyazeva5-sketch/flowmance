from app.ai_agents.base_agent import BaseAgent

class BrandAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="ai_brand_manager",
            description="Бренд-платформа и tone of voice"
        )

    async def run(self, input_data: dict) -> str:
        name = input_data.get("name", "Бренд")

        prompt = f"""
Создай бренд-платформу для {name}

Включи:
- позиционирование
- ключевые сообщения
- tone of voice (3 варианта)
- визуальные подсказки
"""
        return await self.ask(prompt)
