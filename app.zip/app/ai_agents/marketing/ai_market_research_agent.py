from app.ai_agents.base_agent import BaseAgent

class MarketResearchAgent(BaseAgent):
    def __init__(self):
        super().__init__("MarketResearchAgent", "Исследование рынка и трендов")


    async def run(self, input_data: dict) -> str:
        market = input_data.get("market", "рынок")
        prompt = f"""
Сделай исследование рынка: {market}
Дай: объём рынка, тренды, ключевых игроков и перспективные ниши.
"""
        return await self.ask(prompt)
