from app.ai_agents.base_agent import BaseAgent

class TrafficManagerAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="TrafficManagerAgent",
            description="Настройка трафика, рекламные стратегии, медиапланы"
        )

    async def run(self, payload: dict) -> dict:
        niche = payload.get("niche", "онлайн-услуги")
        budget = payload.get("budget", 1000)

        prompt = f"""
Ты — эксперт по рекламе, performance marketing.

Создай стратегию трафика.

Ниша: {niche}
Бюджет: {budget}$

Верни JSON:
{{
  "channels": "...",
  "creative_strategy": "...",
  "targeting": "...",
  "ad_examples": "...",
  "media_plan": "...",
  "optimizations": "..."
}}
"""

        result = await self.ask(prompt)
        return {"traffic_strategy": result}
