from app.schemas.schemas import AgentRequest, AgentResponse


def run(req: AgentRequest) -> AgentResponse:
    return AgentResponse(
        agent="general_ai",
        summary="Базовый анализ запроса выполнен",
        data={
            "input": req.input,
            "notes": "Используется как стартовый агент"
        }
    )
