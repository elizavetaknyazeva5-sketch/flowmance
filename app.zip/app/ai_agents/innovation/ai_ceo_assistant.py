# app/agents/ai_ceo_assistant.py

from pydantic import BaseModel
from fastapi import HTTPException
from openai import OpenAI
import os
from app.ai_agents.base_agent import BaseAgent
from app.schemas.schemas import AgentRequest, AgentResponse
from app.ai_agents.llm_config import DEFAULT_LLM_CONFIG
def run(req: AgentRequest) -> AgentResponse:
    return AgentResponse(
        agent="ceo",
        summary="Определена стратегия продукта",
        data={
            "goal": "Создать AI-сервис с агентами",
            "kpi": ["MVP", "Retention", "Investor demo"],
            "based_on": req.context
        }
    )
# ---------- Модели запросов / ответов ----------

class CEOTaskRequest(BaseModel):
    company_name: str
    industry: str
    goals: list[str] = ["рост", "масштабирование", "запуск продукта"]
    problems: list[str] = []
    tasks_today: list[str] = []
    tasks_week: list[str] = []


class CEOAssistantResult(BaseModel):
    strategy: str
    priorities_day: str
    priorities_week: str
    okr: str
    risk_analysis: str
    summary: str


# ---------- Класс агента ----------

class AICEOAssistant(BaseAgent):
    def __init__(self):
        api_key = os.getenv("OPENROUTER_API_KEY")
        if not api_key:
            raise HTTPException(500, "OPENROUTER_API_KEY not set")

        try:
            self.client = OpenAI(api_key=api_key, base_url="https://openrouter.ai/api/v1")
        except Exception as e:
            raise HTTPException(500, f"OpenRouter init error: {e}")

    # =====================================================
    # Универсальный метод run() — именно его вызывает тест
    # =====================================================

    async def run(self, question: str = "Что мне сделать сегодня?", **kwargs):
        """
        Универсальный метод, который test_agents.py должен видеть.
        """
        prompt = f"Ты — CEO-ассистент. Ответь кратко: {question}"
        return await self.ask(prompt)

    # =====================================================
    # Базовый метод ask — ОБЯЗАТЕЛЕН ДЛЯ ВСЕХ АГЕНТОВ
    # =====================================================

    async def ask(self, prompt: str):
        try:
            response = self.client.chat.completions.create(
                model="gpt-4.1",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.5
            )
            return response.choices[0].message.content
        except Exception as e:
            return f"API error: {e}"


    # ---------- Стратегия ----------

    async def generate_strategy(self, data: CEOTaskRequest):
        prompt = f"""
        Ты — личный AI-ассистент CEO.
        Составь краткую стратегию компании.

        Компания: {data.company_name}
        Отрасль: {data.industry}
        Цели: {data.goals}
        Проблемы: {data.problems}

        Формат:
        - стратегия (5–10 предложений)
        - ключевые рычаги роста (3–5)
        """

        return await self.ask(prompt)


    # ---------- Приоритеты на день ----------

    async def generate_day_priorities(self, data: CEOTaskRequest):
        prompt = f"""
        Составь приоритеты на день для CEO.

        Текущие задачи: {data.tasks_today}
        Цели компании: {data.goals}
        Проблемы: {data.problems}

        Формат:
        - 3 главных приоритета
        - что делегировать
        - что убрать
        """

        return await self.ask(prompt)


    # ---------- Приоритеты на неделю ----------

    async def generate_week_priorities(self, data: CEOTaskRequest):
        prompt = f"""
        Составь недельный фокус CEO.

        Задачи недели: {data.tasks_week}
        Стратегические цели: {data.goals}

        Формат:
        - 5 приоритетов недели
        - ключевые задачи
        - ожидаемые результаты
        """

        return await self.ask(prompt)


    # ---------- OKR ----------

    async def generate_okr(self, data: CEOTaskRequest):
        prompt = f"""
        Составь OKR для компании.

        Компания: {data.company_name}
        Цели: {data.goals}

        Формат:
        - Objectives (3 шт)
        - За каждым — 3 Key Results
        """

        return await self.ask(prompt)


    # ---------- Анализ рисков ----------

    async def generate_risk_analysis(self, data: CEOTaskRequest):
        prompt = f"""
        Сделай анализ рисков компании.

        Отрасль: {data.industry}
        Проблемы: {data.problems}

        Формат:
        - риски
        - вероятность
        - влияние
        - предотвращение
        """

        return await self.ask(prompt)


    # ---------- Итоговый отчёт ----------

    async def generate_summary(self, data: CEOTaskRequest):
        prompt = f"""
        Составь краткий отчёт CEO:

        - что важно прямо сейчас
        - что CEO должен сделать лично
        - что автоматизировать
        - что контролировать еженедельно
        """

        return await self.ask(prompt)


    # ---------- Главный метод ----------

    async def generate_ceo_report(self, data: CEOTaskRequest) -> CEOAssistantResult:

        strategy = await self.generate_strategy(data)
        day = await self.generate_day_priorities(data)
        week = await self.generate_week_priorities(data)
        okr = await self.generate_okr(data)
        risks = await self.generate_risk_analysis(data)
        summary = await self.generate_summary(data)

        return CEOAssistantResult(
            strategy=strategy,
            priorities_day=day,
            priorities_week=week,
            okr=okr,
            risk_analysis=risks,
            summary=summary
        )
