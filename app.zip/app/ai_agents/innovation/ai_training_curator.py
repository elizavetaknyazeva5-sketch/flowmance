# app/agents/ai_training_curator.py

from app.ai_agents.base_agent import BaseAgent
from pydantic import BaseModel


class TrainingCuratorRequest(BaseModel):
    goal: str
    level: str = "beginner"
    timeframe: str = "30 days"
    preferred_format: str = "mixed (video + text + practice)"
    weekly_hours: int = 7
    background: str = ""


class AITrainingCurator(BaseAgent):
    def __init__(self):
        super().__init__(
            name="AITrainingCurator",
            description="Создание полной обучающей программы, roadmap, уроков и тестов"
        )

    async def run(self, goal: str = "Улучшить навыки", **kwargs):
        prompt = f"Составь обучающий план для цели: {goal}"
        return await self.ask(prompt)

        prompt = f"""
Ты — профессиональный методолог, преподаватель и наставник.
Твоя задача — создать полную индивидуальную программу обучения.

Вот данные ученика:

Цель обучения: {data.goal}
Текущий уровень: {data.level}
Срок программы: {data.timeframe}
Предпочтения по формату: {data.preferred_format}
Время в неделю: {data.weekly_hours} часов
Предыдущий опыт: {data.background}

Сформируй структурированный ответ строго в формате JSON:

{{
  "skill_map": "...",
  "roadmap": "...",
  "weekly_plan": "...",
  "daily_lessons": "...",
  "theory_materials": "...",
  "practice_tasks": "...",
  "tests": "...",
  "recommendations": "..."
}}

Где:

- skill_map — карта навыков: ключевые области, поднавыки, индикаторы уровня
- roadmap — дорожная карта на весь срок: этапы, цели, критерии проверки
- weekly_plan — что учить каждую неделю
- daily_lessons — подробные уроки на каждый день
- theory_materials — статьи, книги, видео, документация
- practice_tasks — практические задания и мини-проекты
- tests — тесты и квизы для проверки знаний
- recommendations — советы по обучению, продуктивности, прогрессу, невыгоранию
"""

        result = await self.ask(prompt)

        return {
            "training_program": result
        }

