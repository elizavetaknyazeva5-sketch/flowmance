from app.ai_agents.base_agent import BaseAgent

class GrowthAgent(BaseAgent):
    def __init__(self):
        super().__init__("GrowthAgent", "Growth стратегии и каналы роста")

    async def run(self, input_data: dict) -> str:
        target = input_data.get("target", "ускорение роста")
        prompt = f"""
Предложи growth-стратегию для цели: {target}
Дай 5 каналов с гипотезами и метриками для A/B тестирования.
"""
        return await self.ask(prompt)
