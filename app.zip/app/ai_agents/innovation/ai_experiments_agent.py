from app.ai_agents.base_agent import BaseAgent

class ExperimentsAgent(BaseAgent):
    def __init__(self):
        super().__init__("ExperimentsAgent", "Эксперименты и гипотезы")

    async def run(self, input_data: dict) -> str:
        metric = input_data.get("metric", "conversion")
        prompt = f"""
Сгенерируй 10 гипотез для увеличения метрики {metric}
Для каждой: описание, ожидаемый эффект, как измерять.
"""
        return await self.ask(prompt)
