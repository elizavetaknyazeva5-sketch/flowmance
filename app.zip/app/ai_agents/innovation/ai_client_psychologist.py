from app.ai_agents.base_agent import BaseAgent
from pydantic import BaseModel


class PsychologistRequest(BaseModel):
    situation: str
    emotions: list[str] = []
    problems: list[str] = []
    triggers: list[str] = []
    goals: list[str] = []


class AIClientPsychologist(BaseAgent):
    def __init__(self):
        super().__init__(
            name="AIClientPsychologist",
            description="Эмоциональный разбор, когнитивные искажения, рекомендации и план действий"
        )

    async def run(self, situation: str = "Клиент нервничает", **kwargs):
        prompt = f"Проанализируй клиентскую ситуацию: {situation}"
        return await self.ask(prompt)

        # ---------- Единый большой prompt ----------
        prompt = f"""
Ты — профессиональный клинический психолог с эмпатичным подходом.

Ниже данные клиента:

Ситуация: {data.situation}
Эмоции: {data.emotions}
Проблемы: {data.problems}
Триггеры: {data.triggers}
Цели: {data.goals}

Сформируй структурированный анализ строго в формате JSON со следующими блоками:

{{
  "emotional_analysis": "...",
  "cognitive_distortions": "...",
  "root_causes": "...",
  "recommendations": "...",
  "exercises": "...",
  "action_plan": "..."
}}

Где:
- emotional_analysis — глубокий разбор эмоций, скрытых чувств и их происхождения
- cognitive_distortions — выявленные когнитивные искажения и рекомендации по работе с ними
- root_causes — гипотезы корневых причин состояния
- recommendations — мягкие, реалистичные рекомендации
- exercises — дыхательные, телесные, когнитивные практики
- action_plan — план действий: 10 минут, сутки, неделя
"""

        result = await self.ask(prompt)

        # Возвращаем как dict — FastAPI сам превратит в JSON
        return {"psychology_report": result}

