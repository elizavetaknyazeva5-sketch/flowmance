# app/ai_agents/agents.py
from typing import Dict

class BaseAgent:
    def __init__(self, name: str):
        self.name = name

    async def run(self, input_data: Dict, context: Dict) -> Dict:
        """Возвращает результат агента в едином формате"""
        return {
            "agent": self.name,
            "summary": f"{self.name} выполнен успешно",
            "data": {}
        }

from .development import (
    ai_data_agent,
    ai_designer,
    ai_ux,
    ai_video_creator,
    ai_webbuilder,
)
from .innovation import (
    ai_ceo_assistant,
    ai_client_psychologist,
    ai_experiments_agent,
    ai_growth_agent,
    ai_training_curator,
)
from .internal import (
    ai_crm_agent,
    ai_project_manager,
    ai_workflow_builder,
)
from .marketing import (
    ai_brand_manager,
    ai_competitor_agent,
    ai_content_agent,
    ai_copywriter,
    ai_marketing_agent,
    ai_market_research_agent,
    ai_seo_specialist,
    ai_smm_manager,
    ai_traffic_manager,
)
from .operations import (
    ai_accountant,
    ai_admin_assistant,
    ai_compliance_agent,
    ai_hr,
    ai_legal_agent,
    ai_onboarding_agent,
)
from .sales import (
    ai_call_bot,
    ai_client_service_manager,
    ai_lead_scoring_agent,
    ai_sales_manager,
)
from .strategy import (
    ai_business_analyst,
    ai_finance_docs_agent,
    ai_financial_analyst,
    ai_operations_agent,
    ai_product_manager,
    ai_strategy_agent,
)

AGENTS = {
    "ai_data_agent": ai_data_agent.AIDataAgent(),
    "ai_designer": ai_designer.DesignAgent(),
    "ai_ux": ai_ux.UXAgent(),
    "ai_video_creator": ai_video_creator.AIVideoCreator(),
    "ai_webbuilder": ai_webbuilder.AIWebBuilder(),

    "ai_ceo_assistant": ai_ceo_assistant.AICEOAssistant(),
    "ai_client_psychologist": ai_client_psychologist.AIClientPsychologist(),
    "ai_experiments_agent": ai_experiments_agent.ExperimentsAgent(),
    "ai_growth_agent": ai_growth_agent.GrowthAgent(),
    "ai_training_curator": ai_training_curator.AITrainingCurator(),

    "ai_crm_agent": ai_crm_agent.CRMAgent(),
    "ai_project_manager": ai_project_manager.AIProjectManager(),
    "ai_workflow_builder": ai_workflow_builder.WorkflowBuilderAgent(),

    "ai_brand_manager": ai_brand_manager.BrandAgent(),
    "ai_competitor_agent": ai_competitor_agent.CompetitorAgent(),
    "ai_content_agent": ai_content_agent.ContentAgent(),
    "ai_copywriter": ai_copywriter.AICopywriter(),
    "ai_marketing_agent": ai_marketing_agent.MarketingAgent(),
    "ai_market_research_agent": ai_market_research_agent.MarketResearchAgent(),
    "ai_seo_specialist": ai_seo_specialist.SEOAgent(),
    "ai_smm_manager": ai_smm_manager.AISMMAgent(),
    "ai_traffic_manager": ai_traffic_manager.TrafficManagerAgent(),

    "ai_accountant": ai_accountant.AIAccountantAgent(),
    "ai_admin_assistant": ai_admin_assistant.AdminAssistantAgent(),
    "ai_compliance_agent": ai_compliance_agent.ComplianceAgent(),
    "ai_hr": ai_hr.AIHRAgent(),
    "ai_legal_agent": ai_legal_agent.AILegalAgent(),
    "ai_onboarding_agent": ai_onboarding_agent.AIOnboardingAgent(),

    "ai_call_bot": ai_call_bot.CallBotAgent(),
    "ai_client_service_manager": ai_client_service_manager.ClientServiceManagerAgent(),
    "ai_lead_scoring_agent": ai_lead_scoring_agent.AILeadScoringAgent(),
    "ai_sales_manager": ai_sales_manager.AISalesAgent(),

    "ai_business_analyst": ai_business_analyst.AIBusinessAnalystAgent(),
    "ai_finance_docs_agent": ai_finance_docs_agent.AIFinanceDocsAgent(),
    "ai_financial_analyst": ai_financial_analyst.AIFinanceAgent(),
    "ai_operations_agent": ai_operations_agent.AIOperationsAgent(),
    "ai_product_manager": ai_product_manager.AIProductManagerAgent(),
    "ai_strategy_agent": ai_strategy_agent.AIStrategyAgent(),
}

def get_all_agent_names():
    return list(AGENTS.keys())
