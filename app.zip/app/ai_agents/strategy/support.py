from app.ai_agents.base_agent import BaseAgent

class SupportAgent(BaseAgent):
    def __init__(self):
        super().__init__("SupportAgent", "Автоответы и скрипты для техподдержек")

    async def run(self, input_data: dict) -> str:
        tickets = input_data.get("tickets", [])
        prompt = f"""
Проанализируй типичные тикеты: {tickets}
Сгенерируй шаблоны ответов, классификацию по приоритету и инструкции для escalation.
"""
        return await self.ask(prompt)
