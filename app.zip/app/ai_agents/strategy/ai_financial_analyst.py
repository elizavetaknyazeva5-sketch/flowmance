from app.ai_agents.base_agent import BaseAgent

class AIFinanceAgent(BaseAgent):
    def __init__(self):
        super().__init__("AIFinanceAgent", "Финансовый анализ и прогноз")
    

    async def run(self, input_data: dict) -> str:
        data = input_data.get("data", {})
        prompt = f"""
Сделай финансовый анализ по данным: {data}
Дай: P&L прогноз на 12 месяцев, ключевые метрики, рекомендации по снижению затрат.
"""
        return await self.ask(prompt)
