from app.ai_agents.base_agent import BaseAgent

class AIBusinessAnalystAgent(BaseAgent):
    def __init__(self):
        super().__init__("AIBusinessAnalystAgent", "SWOT, анализ ниши и конкурентов")

    async def run(self, input_data: dict) -> str:
        company = input_data.get("company", "Компания")
        niche = input_data.get("niche", "Ниша")
        prompt = f"""
Проведи подробный SWOT-анализ.

Компания: {company}
Ниша: {niche}

Выведи:
1) SWOT (Strengths, Weaknesses, Opportunities, Threats)
2) 3–5 основных конкурентов и их преимущества/слабости
3) 5 практических рекомендаций
Формат: Markdown.
"""
        return await self.ask(prompt)
