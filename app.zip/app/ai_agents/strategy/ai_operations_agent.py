from app.ai_agents.base_agent import BaseAgent

class AIOperationsAgent(BaseAgent):
    def __init__(self):
        super().__init__("AIOperationsAgent", "Операционные процессы и SOP")
    

    async def run(self, input_data: dict) -> str:
        area = input_data.get("area", "операции")
        prompt = f"""
Опиши операционный процесс для: {area}.

Включи:
- пошаговые SOP
- ответственных ролей
- контрольные метрики
- рекомендации по автоматизации
"""
        return await self.ask(prompt)
