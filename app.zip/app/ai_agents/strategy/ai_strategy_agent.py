from app.ai_agents.base_agent import BaseAgent

class AIStrategyAgent(BaseAgent):
    def __init__(self):
        super().__init__("AIStrategyAgent", "Стратегическое планирование и roadmap")

    async def run(self, input_data: dict) -> str:
        horizon = input_data.get("horizon", "12 месяцев")
        goals = input_data.get("goals", "увеличение выручки")
        prompt = f"""
Составь стратегию на {horizon} с целью: {goals}.

Дай:
- KPI по кварталам
- Главные инициативы
- Ресурсы и риски
Формат: план с шагами и сроками.
"""
        return await self.ask(prompt)
