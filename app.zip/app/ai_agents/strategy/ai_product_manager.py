from app.ai_agents.base_agent import BaseAgent

class AIProductManagerAgent(BaseAgent):
    def __init__(self):
        super().__init__("AIProductManagerAgent", "Фичи продукта, roadmap и приоритизация")
    

    async def run(self, input_data: dict) -> str:
        idea = input_data.get("idea", "новая фича")
        prompt = f"""
Сформируй набор фич для идеи: {idea}
Включи: user stories, MVP scope, метрики успеха, этапы разработки.
"""
        return await self.ask(prompt)
