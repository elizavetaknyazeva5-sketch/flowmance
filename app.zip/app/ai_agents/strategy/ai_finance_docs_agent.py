from app.ai_agents.base_agent import BaseAgent

class AIFinanceDocsAgent(BaseAgent):
    def __init__(self):
        super().__init__("AIFinanceDocsAgent", "Генерация счетов, актов, шаблонов")
    

    async def run(self, input_data: dict) -> str:
        doc_type = input_data.get("doc_type", "invoice")
        details = input_data.get("details", {})
        prompt = f"""
Создай шаблон {doc_type} по деталям: {details}
Включи: поля, пример заполнения, рекомендации по юридической проверке.
"""
        return await self.ask(prompt)
