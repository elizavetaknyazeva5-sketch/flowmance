DEFAULT_LLM_CONFIG = {
    "model": "gpt-4o-mini",  # или gpt-4.1-mini
    "temperature": 0.4,
    "max_tokens": 800
}