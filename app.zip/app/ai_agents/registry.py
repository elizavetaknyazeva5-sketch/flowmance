# app/ai_agents/registry.py
from app.ai_agents.agents import AGENTS

agent_registry = AGENTS
