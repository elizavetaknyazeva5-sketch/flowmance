from sqlalchemy import Column, Integer, String, Boolean, Enum
import enum
from app.core.database import Base

# Перечисление ролей пользователя
class UserRole(str, enum.Enum):
    admin = "admin"
    client = "client"
    manager = "manager"

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    name = Column(String, nullable=True)  # для совместимости с user_schema
    is_active = Column(Boolean, default=True, nullable=False)
    is_superuser = Column(Boolean, default=False, nullable=False)
    role = Column(
    Enum(UserRole, name="userrole", create_type=False)   # ← вот здесь проблема
)
