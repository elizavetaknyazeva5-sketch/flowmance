from app.core.database import Base, engine
from app.core.config import Settings
# Импортируем все модели, чтобы SQLAlchemy их видел
from app.models import user, project, agent

def init_db():
    print("Создаём таблицы в базе данных...")
    Base.metadata.create_all(bind=engine)
    print("Все таблицы созданы!")

if __name__ == "__main__":
    init_db()
    
settings = Settings()
__all__ = ["settings"]
