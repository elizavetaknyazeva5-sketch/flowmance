# app/models/agent_models.py
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from app.core.database import Base

class Agent(Base):
    __tablename__ = "agent_responses"

    id = Column(Integer, primary_key=True, index=True)
    agent_name = Column(String, index=True, nullable=False)
    user_id = Column(Integer, nullable=True) 
    description = Column(String)
    module_path = Column(String) # опционально
    project_id = Column(Integer, nullable=True)       # опционально
    input_payload = Column(Text, nullable=True)
    result = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

# Если у тебя уже есть User/Project модели, можно оставить как есть.
