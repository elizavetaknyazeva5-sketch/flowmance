from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.schemas import user_schema
from app.core import crud
from app.core.database import get_db

router = APIRouter(prefix="/users", tags=["Users"])

@router.post("/", response_model=user_schema.User, summary="Создать пользователя")
def create_user(user: user_schema.UserCreate, db: Session = Depends(get_db)):
    """Создает нового пользователя"""
    return crud.create_user(db, user)

@router.get("/{user_id}", response_model=user_schema.User, summary="Получить пользователя")
def get_user(user_id: int, db: Session = Depends(get_db)):
    """Получить пользователя по ID"""
    user = crud.get_user(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")
    return user

@router.delete("/{user_id}", summary="Удалить пользователя")
def delete_user(user_id: int, db: Session = Depends(get_db)):
    """Удалить пользователя по ID"""
    user = crud.delete_user(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")
    return {"message": "Пользователь успешно удален"}