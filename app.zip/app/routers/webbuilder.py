from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.ai_agents.development.ai_webbuilder import AIWebBuilder

router = APIRouter(prefix="/webbuilder", tags=["AI-WebBuilder"])

class WebsitePrompt(BaseModel):
    prompt: str

@router.post("/")
def create_website(request: WebsitePrompt):
    """Создает HTML-сайт по текстовому запросу"""
    try:
        builder = AIWebBuilder()
        file_path = builder.generate_site(request.prompt)
        return {"message": "Сайт успешно создан!", "file_path": file_path}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка при создании сайта: {str(e)}")