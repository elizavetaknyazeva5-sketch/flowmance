from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.schemas import agent_schema
from app.core import crud
from app.core.database import get_db

router = APIRouter(prefix="/agents", tags=["Agents"])

@router.post("/", response_model=agent_schema.Agent, summary="Создать агента")
def create_agent(agent: agent_schema.AgentCreate, db: Session = Depends(get_db)):
    return crud.create_agent(db, agent)

@router.get("/", response_model=List[agent_schema.Agent], summary="Получить всех агентов")
def get_agents(db: Session = Depends(get_db)):
    return crud.get_agents(db)

@router.get("/{agent_id}", response_model=agent_schema.Agent, summary="Получить агента")
def get_agent(agent_id: int, db: Session = Depends(get_db)):
    agent = crud.get_agent(db, agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Агент не найден")
    return agent

@router.delete("/{agent_id}", summary="Удалить агента")
def delete_agent(agent_id: int, db: Session = Depends(get_db)):
    agent = crud.delete_agent(db, agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Агент не найден")
    return {"message": "Агент успешно удален"}
