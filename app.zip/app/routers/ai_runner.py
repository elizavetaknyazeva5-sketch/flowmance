from fastapi import APIRouter, HTTPException
from app.ai_agents.registry import agents

router = APIRouter()

@router.post("/agent/{agent_name}")
async def run_agent(agent_name: str, payload: dict):
    if agent_name not in agents:
        raise HTTPException(status_code=404, detail="Agent not found")

    result = await agents[agent_name].run(payload)

    return {"agent": agent_name, "result": result}

async def run_pipeline(agents, initial_input):
    context = {
        "input": initial_input
    }

    for agent in agents:
        result = await agent.run(context)
        context[agent.name] = result

    return context