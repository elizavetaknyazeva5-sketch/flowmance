from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.schemas import project_schema
from app.core import crud
from app.core.database import get_db

router = APIRouter(prefix="/projects", tags=["Projects"])

@router.post("/", response_model=project_schema.Project, summary="Создать проект")
def create_project(project: project_schema.ProjectCreate, user_id: int = 1, db: Session = Depends(get_db)):
    """Создает новый проект"""
    return crud.create_project(db, project, user_id)

@router.get("/{project_id}", response_model=project_schema.Project, summary="Получить проект")
def get_project(project_id: int, db: Session = Depends(get_db)):
    """Получить проект по ID"""
    project = crud.get_project(db, project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Проект не найден")
    return project

@router.get("/user/{user_id}", response_model=List[project_schema.Project], summary="Получить проекты пользователя")
def get_user_projects(user_id: int, db: Session = Depends(get_db)):
    """Получить все проекты пользователя"""
    return crud.get_projects_by_user(db, user_id)

@router.put("/{project_id}", response_model=project_schema.Project, summary="Обновить проект")
def update_project(project_id: int, project: project_schema.ProjectUpdate, db: Session = Depends(get_db)):
    """Обновить проект"""
    updated_project = crud.update_project(db, project_id, project)
    if not updated_project:
        raise HTTPException(status_code=404, detail="Проект не найден")
    return updated_project