from fastapi import APIRouter

router = APIRouter(prefix="/workflows", tags=["Workflows"])

@router.get("/")
def get_workflows():
    """Получить список всех workflow"""
    return {"message": "Workflows endpoint - в разработке"}

