from typing import List, Dict, Any
from app.ai_agents.loader import loaded_agents


class WorkflowManager:
    def __init__(self):
        self.agents = loaded_agents

    async def run_workflow(self, steps: List[Dict[str, Any]], initial_payload: dict):
        """
        steps = [
            { "agent": "MarketResearchAgent", "input_key": "topic" },
            { "agent": "ContentAgent" },
            { "agent": "AICopywriter" }
        ]
        """
        payload = initial_payload

        for step in steps:
            agent_name = step["agent"]
            agent = self.agents.get(agent_name)

            if not agent:
                raise ValueError(f"Agent '{agent_name}' not found")

            print(f"▶ Запуск агента: {agent_name}")

            # отправляем данные агенту
            result = await agent.run(payload)

            # оборачиваем в dict если агент вернул не dict
            if not isinstance(result, dict):
                result = {"result": result}

            # передаём результат дальше
            payload.update(result)

        return payload
