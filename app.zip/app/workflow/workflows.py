website_workflow = [
    {"agent": "MarketResearchAgent"},
    {"agent": "ContentAgent"},
    {"agent": "AICopywriter"},
    {"agent": "DesignAgent"},
    {"agent": "UXAgent"},
    {"agent": "AIWebBuilder"},
]

marketing_workflow = [
    {"agent": "CompetitorAgent"},
    {"agent": "MarketingAgent"},
    {"agent": "ContentAgent"},
    {"agent": "AISMMAgent"},
    {"agent": "TrafficManagerAgent"},
]

sales_workflow = [
    {"agent": "AIBusinessAnalystAgent"},
    {"agent": "AISalesAgent"},
    {"agent": "CallBotAgent"},
]
