from fastapi import APIRouter

router = APIRouter()

@router.post("/test_agent")
async def test_agent(payload: dict):
    context = payload.get("context", {})
    return {
        "agent": "test_agent",
        "status": "done",
        "message": "Агент успешно отработал",
        "context_keys": list(context.keys())
    }
