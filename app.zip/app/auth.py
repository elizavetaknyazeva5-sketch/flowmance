# app/auth.py
from passlib.context import CryptContext
import jwt
from datetime import datetime, timedelta
import os
from typing import Optional

PWD = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET = os.getenv("JWT_SECRET", "dev-secret-change-me")
ALGO = "HS256"
ACCESS_EXPIRE_MINUTES = 60 * 24

def hash_password(password: str) -> str:
    return PWD.hash(password)

def verify_password(password: str, hashed: str) -> bool:
    return PWD.verify(password, hashed)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET, algorithm=ALGO)

def decode_token(token: str) -> dict:
    return jwt.decode(token, SECRET, algorithms=[ALGO])
