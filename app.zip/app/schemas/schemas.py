from pydantic import BaseModel, EmailStr
from typing import Dict, Any, Optional

class AgentRequest(BaseModel):
    input: Dict[str, Any]
    context: Optional[Dict[str, Any]] = {}


class AgentResponse(BaseModel):
    agent: str
    summary: str
    data: Dict[str, Any]

class UserReadSchema(BaseModel):
    id: int
    email: EmailStr
    is_active: bool
    is_superuser: bool

    class Config:
        from_attributes = True
