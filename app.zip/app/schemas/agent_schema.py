from pydantic import BaseModel
from typing import Any, Dict, Optional


class AgentBase(BaseModel):
    name: str
    description: Optional[str] = None
    config: Optional[Dict[str, Any]] = None


# Создание агента
class AgentCreate(AgentBase):
    pass


# Ответ от API: содержит id
class Agent(AgentBase):
    id: int

    class Config:
        from_attributes = True  # старое: orm_mode = True


# Модель для запуска агента
class AgentRequest(BaseModel):
    payload: Dict[str, Any]
