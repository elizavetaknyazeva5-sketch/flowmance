from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.schemas.schemas import AgentRequest
from pydantic import BaseModel
# --- Настройки ---
from app.core.config import settings
from fastapi import APIRouter
# --- Подключаем маршруты ---
from app.ai_agents.routes import router as agents_router
from app.workflow.routes import router as workflow_router
from fastapi import APIRouter, HTTPException
from typing import Any, Dict, Optional
from app.ai_agents.agents import AGENTS
# --- Реестр агентов ---
from app.ai_agents.registry import agent_registry

# --- DB (если нужна) ---
# from app.db.database import init_db

context: Dict[str, dict] = {}
# --- Логирование ---
import logging

logger = logging.getLogger("flowmance")
logger.setLevel(logging.INFO)

app = FastAPI(
    title="Flowmance AI Service",
    description="AI-сервис с 38 агентами для автоматизации маркетинга, продаж и операций",
    version="1.0.0",
)

# ================================
#           CORS
# ================================
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ================================
#       СТАРТОВЫЕ ХУКИ
# ================================
@app.on_event("startup")
async def startup_event():
    logger.info("🚀 Flowmance запускается...")
    
    # Initialize DB
    # await init_db()

    # Проверяем агентов
    logger.info(f"Загружено агентов: {len(agent_registry)}")
    for name in agent_registry.keys():
        logger.info(f"  🔹 {name}")


@app.on_event("shutdown")
async def shutdown_event():
    logger.info("🛑 Flowmance остановлен.")


# ================================
#          РОУТЫ
# ================================
app.include_router(agents_router, prefix="/agents", tags=["Agents"])
app.include_router(workflow_router, prefix="/workflow", tags=["Workflows"])


# ================================
#         HEALTH CHECK
# ================================
@app.get("/")
async def root():
    return {
        "status": "ok",
        "agents_loaded": len(agent_registry),
        "service": "Flowmance AI",
    }


# ================================
#       DEBUG ЭНДПОИНТЫ
# ================================
@app.get("/debug/loaded-agents")
async def debug_agents():
    return {
        "loaded_agents": list(agent_registry.keys())
    }


@app.get("/debug/settings")
async def debug_settings():
    return {
        "allowed_origins": settings.ALLOWED_ORIGINS,
        "mode": settings.MODE,
    }


@app.get("/health")
def health():
    return {"status": "ok"}

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # позже ограничим
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/test_agent")
async def test_agent(payload: dict):
    return {
        "status": "ok",
        "received": payload
    }
    
    
@app.post("/general_ai")
async def general_ai(context: dict):
    return {"ok": True}

@app.post("/general_ai")
def general(req: AgentRequest):
    return general_ai.run(req)


@app.get("/")
def health():
    return {"status": "ok"}

@app.post("/run_agent/{agent_name}")
async def run_agent(agent_name: str, input_data: Dict = {}):
    agent = agent_registry.get(agent_name)
    if agent_name not in agent_registry:
        raise HTTPException (status_code=404, detail="Agent not found")
    
    agent = agent_registry[agent_name]
    result = await agent.run(input_data, context)
    
    return {
        "status": "ok",
        "agent": agent_name,
        "data": result
    }

@app.post("/agents/{agent_name}")
async def run_agent(agent_name: str, payload: Dict[str, Any] = {}):
    # 1. Проверяем, что агент существует
    if agent_name not in agent_registry:
        raise HTTPException(
            status_code=404,
            detail=f"Agent '{agent_name}' not found"
        )

    agent = agent_registry[agent_name]

    # 2. Запускаем агента (ВАЖНО: await)
    try:
        result = await agent.run(payload)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

    # 3. Единый формат ответа
    if isinstance(result, dict):
        summary = result.get("summary", "")
    else:
        summary = str(result)


    return {
    "status": "ok",
    "agent": agent_name,
    "summary": summary,
    "data": result
}


@app.get("/agents/list")
async def list_agents():
    return {"agents": list(AGENTS.keys())}