from fastapi import APIRouter
from app.services.agent_loader import run_agent

router = APIRouter()

@router.post("/run/{agent_name}")
async def run_agent_api(agent_name: str, payload: dict):
    result = await run_agent(agent_name, payload)
    return {"agent": agent_name, "result": result}
